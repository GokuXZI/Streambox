import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      bodySizeLimit: "4gb",
    },
  },
  // Required for better-sqlite3 native module
  serverExternalPackages: ["better-sqlite3"],
  // Empty turbopack config to silence the warning when using webpack fallback
  turbopack: {},
  // Webpack configuration for native modules (used on platforms without Turbopack support)
  webpack: (config, { isServer }) => {
    if (isServer) {
      // Handle native modules
      config.externals = config.externals || [];
      if (Array.isArray(config.externals)) {
        config.externals.push("better-sqlite3");
      }
    }
    return config;
  },
};

export default nextConfig;
