import fs from "fs";
import path from "path";

const STORAGE_PATH = process.env.STORAGE_PATH || "storage";

const storageBase = path.join(/*turbopackIgnore: true*/ process.cwd(), STORAGE_PATH);

export const DIRS = {
  videos: path.join(storageBase, "videos"),
  thumbnails: path.join(storageBase, "thumbnails"),
  processed: path.join(storageBase, "processed"),
  temp: path.join(storageBase, "temp"),
};

export function initStorage(): void {
  for (const dir of Object.values(DIRS)) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

initStorage();

export function sanitizeFilename(filename: string): string {
  let safe = path.basename(filename);
  safe = safe.replace(/[^a-zA-Z0-9._-]/g, "_");
  safe = safe.replace(/\.{2,}/g, ".");
  safe = safe.replace(/^[._-]+/, "");
  if (!safe || safe.length === 0) safe = "video";
  if (safe.length > 200) safe = safe.substring(0, 200);
  return safe;
}

export function getVideoPath(filename: string): string {
  const resolved = path.resolve(DIRS.videos, path.basename(filename));
  if (!resolved.startsWith(DIRS.videos)) {
    throw new Error("Path traversal detected");
  }
  return resolved;
}

export function getThumbnailPath(filename: string): string {
  const resolved = path.resolve(DIRS.thumbnails, path.basename(filename));
  if (!resolved.startsWith(DIRS.thumbnails)) {
    throw new Error("Path traversal detected");
  }
  return resolved;
}

export function getProcessedPath(filename: string): string {
  const resolved = path.resolve(DIRS.processed, path.basename(filename));
  if (!resolved.startsWith(DIRS.processed)) {
    throw new Error("Path traversal detected");
  }
  return resolved;
}

export function getTempPath(filename: string): string {
  const resolved = path.resolve(DIRS.temp, path.basename(filename));
  if (!resolved.startsWith(DIRS.temp)) {
    throw new Error("Path traversal detected");
  }
  return resolved;
}

export function fileExists(filePath: string): boolean {
  try {
    return fs.existsSync(filePath);
  } catch {
    return false;
  }
}

export function getFileSize(filePath: string): number {
  try {
    const stat = fs.statSync(filePath);
    return stat.size;
  } catch {
    return 0;
  }
}

export function deleteFile(filePath: string): boolean {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

const ALLOWED_VIDEO_EXTENSIONS = new Set([
  ".mp4", ".webm", ".mkv", ".mov", ".avi", ".m4v", ".ogv", ".3gp", ".flv", ".wmv", ".ts",
]);

const ALLOWED_VIDEO_MIMES = new Set([
  "video/mp4", "video/webm", "video/x-matroska", "video/quicktime",
  "video/x-msvideo", "video/x-m4v", "video/ogg", "video/3gpp",
  "video/x-flv", "video/x-ms-wmv", "video/mp2t",
  "application/octet-stream",
]);

export function isValidVideoFile(filename: string, mimeType?: string): boolean {
  const ext = path.extname(filename).toLowerCase();
  if (!ALLOWED_VIDEO_EXTENSIONS.has(ext)) return false;
  if (mimeType && !ALLOWED_VIDEO_MIMES.has(mimeType) && !mimeType.startsWith("video/")) return false;
  return true;
}

export function getContentType(filename: string): string {
  const ext = path.extname(filename).toLowerCase();
  const types: Record<string, string> = {
    ".mp4": "video/mp4",
    ".webm": "video/webm",
    ".mkv": "video/x-matroska",
    ".mov": "video/quicktime",
    ".avi": "video/x-msvideo",
    ".m4v": "video/x-m4v",
    ".ogv": "video/ogg",
    ".3gp": "video/3gpp",
    ".flv": "video/x-flv",
    ".wmv": "video/x-ms-wmv",
    ".ts": "video/mp2t",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
  };
  return types[ext] || "application/octet-stream";
}
