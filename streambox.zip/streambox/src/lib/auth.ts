import { headers } from "next/headers";

const ADMIN_TOKEN = process.env.ADMIN_TOKEN || "streambox-admin-2024";

export async function isAdminRequest(): Promise<boolean> {
  const hdrs = await headers();
  const authHeader = hdrs.get("authorization");
  if (authHeader) {
    const token = authHeader.replace("Bearer ", "").trim();
    if (token === ADMIN_TOKEN) return true;
  }
  const tokenHeader = hdrs.get("x-admin-token");
  if (tokenHeader === ADMIN_TOKEN) return true;
  return false;
}

export function validateAdminToken(token: string | null): boolean {
  if (!token) return false;
  return token === ADMIN_TOKEN;
}
