import { execFile } from "child_process";
import { promisify } from "util";
import path from "path";
import fs from "fs";

const execFileAsync = promisify(execFile);

export interface VideoMetadata {
  duration: number | null;
  width: number | null;
  height: number | null;
  fps: number | null;
  bitrate: number | null;
  video_codec: string | null;
  audio_codec: string | null;
  container_format: string | null;
}

export async function probeVideo(filePath: string): Promise<VideoMetadata> {
  try {
    const { stdout } = await execFileAsync("ffprobe", [
      "-v", "quiet",
      "-print_format", "json",
      "-show_format",
      "-show_streams",
      filePath,
    ], { timeout: 30000 });

    const data = JSON.parse(stdout);
    const videoStream = data.streams?.find((s: { codec_type: string }) => s.codec_type === "video");
    const audioStream = data.streams?.find((s: { codec_type: string }) => s.codec_type === "audio");
    const format = data.format || {};

    let fps: number | null = null;
    if (videoStream?.r_frame_rate) {
      const parts = videoStream.r_frame_rate.split("/");
      if (parts.length === 2 && Number(parts[1]) > 0) {
        fps = Math.round((Number(parts[0]) / Number(parts[1])) * 100) / 100;
      }
    }

    return {
      duration: format.duration ? parseFloat(format.duration) : null,
      width: videoStream?.width || null,
      height: videoStream?.height || null,
      fps,
      bitrate: format.bit_rate ? parseInt(format.bit_rate) : null,
      video_codec: videoStream?.codec_name || null,
      audio_codec: audioStream?.codec_name || null,
      container_format: format.format_name || null,
    };
  } catch (error) {
    console.error("FFprobe error:", error);
    return {
      duration: null,
      width: null,
      height: null,
      fps: null,
      bitrate: null,
      video_codec: null,
      audio_codec: null,
      container_format: null,
    };
  }
}

export async function generateThumbnail(
  videoPath: string,
  thumbnailPath: string,
  timestamp?: string
): Promise<boolean> {
  try {
    const dir = path.dirname(thumbnailPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    const time = timestamp || "00:00:02";

    await execFileAsync("ffmpeg", [
      "-y",
      "-i", videoPath,
      "-ss", time,
      "-vframes", "1",
      "-vf", "scale=640:-2",
      "-q:v", "5",
      thumbnailPath,
    ], { timeout: 60000 });

    return fs.existsSync(thumbnailPath);
  } catch (error) {
    console.error("Thumbnail generation error:", error);
    // Try at 0 seconds as fallback
    try {
      await execFileAsync("ffmpeg", [
        "-y",
        "-i", videoPath,
        "-vframes", "1",
        "-vf", "scale=640:-2",
        "-q:v", "5",
        thumbnailPath,
      ], { timeout: 60000 });
      return fs.existsSync(thumbnailPath);
    } catch {
      return false;
    }
  }
}

export function isBrowserCompatible(metadata: VideoMetadata): boolean {
  const compatibleVideoCodecs = ["h264", "vp8", "vp9", "av1"];
  const compatibleAudioCodecs = ["aac", "opus", "vorbis", "mp3", null];

  const videoOk = metadata.video_codec
    ? compatibleVideoCodecs.includes(metadata.video_codec.toLowerCase())
    : true;
  const audioOk = metadata.audio_codec
    ? compatibleAudioCodecs.includes(metadata.audio_codec.toLowerCase())
    : true;

  return videoOk && audioOk;
}

export async function ffmpegAvailable(): Promise<boolean> {
  try {
    await execFileAsync("ffmpeg", ["-version"], { timeout: 5000 });
    return true;
  } catch {
    return false;
  }
}

export function getResolutionLabel(width: number | null, height: number | null): string {
  if (!height) return "Unknown";
  if (height >= 2160) return "4K";
  if (height >= 1440) return "1440p";
  if (height >= 1080) return "1080p";
  if (height >= 720) return "720p";
  if (height >= 480) return "480p";
  if (height >= 360) return "360p";
  return `${height}p`;
}

export function formatDuration(seconds: number | null): string {
  if (!seconds || seconds <= 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}
