import path from "path";
import fs from "fs";

const DB_PATH = process.env.SQLITE_DB_PATH || "data/streaming.db";
const dbFilePath = path.join(/*turbopackIgnore: true*/ process.cwd(), DB_PATH);

// Ensure data directory exists
const dbDir = path.dirname(dbFilePath);
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

// We'll use a simple JSON-based storage that mimics SQLite behavior
// This is the most portable solution for Termux

interface DatabaseState {
  videos: VideoRecord[];
}

let dbState: DatabaseState | null = null;

function loadDatabase(): DatabaseState {
  if (dbState) return dbState;
  
  if (fs.existsSync(dbFilePath)) {
    try {
      const data = fs.readFileSync(dbFilePath, "utf-8");
      dbState = JSON.parse(data) as DatabaseState;
    } catch {
      dbState = { videos: [] };
    }
  } else {
    dbState = { videos: [] };
  }
  return dbState;
}

function saveDatabase(): void {
  if (dbState) {
    fs.writeFileSync(dbFilePath, JSON.stringify(dbState, null, 2));
  }
}

export interface VideoRecord {
  id: string;
  title: string;
  description: string;
  original_filename: string;
  storage_path: string;
  processed_path: string | null;
  thumbnail_path: string | null;
  mime_type: string;
  file_size: number;
  duration: number | null;
  width: number | null;
  height: number | null;
  fps: number | null;
  bitrate: number | null;
  video_codec: string | null;
  audio_codec: string | null;
  container_format: string | null;
  status: string;
  processing_error: string | null;
  created_at: string;
  updated_at: string;
}

export function getDb(): DatabaseState {
  return loadDatabase();
}

export function insertVideo(video: Partial<VideoRecord> & { id: string; title: string; original_filename: string; storage_path: string }): void {
  const db = loadDatabase();
  const now = new Date().toISOString().replace("T", " ").split(".")[0];
  
  const newVideo: VideoRecord = {
    id: video.id,
    title: video.title,
    description: video.description || "",
    original_filename: video.original_filename,
    storage_path: video.storage_path,
    processed_path: video.processed_path || null,
    thumbnail_path: video.thumbnail_path || null,
    mime_type: video.mime_type || "video/mp4",
    file_size: video.file_size || 0,
    duration: video.duration || null,
    width: video.width || null,
    height: video.height || null,
    fps: video.fps || null,
    bitrate: video.bitrate || null,
    video_codec: video.video_codec || null,
    audio_codec: video.audio_codec || null,
    container_format: video.container_format || null,
    status: video.status || "uploading",
    processing_error: video.processing_error || null,
    created_at: now,
    updated_at: now,
  };
  
  db.videos.push(newVideo);
  saveDatabase();
}

export function updateVideoMetadata(id: string, metadata: Partial<VideoRecord>): void {
  const db = loadDatabase();
  const index = db.videos.findIndex((v) => v.id === id);
  
  if (index === -1) return;
  
  const now = new Date().toISOString().replace("T", " ").split(".")[0];
  
  for (const [key, value] of Object.entries(metadata)) {
    if (key !== "id" && value !== undefined) {
      (db.videos[index] as unknown as Record<string, unknown>)[key] = value;
    }
  }
  db.videos[index].updated_at = now;
  
  saveDatabase();
}

export function getVideoById(id: string): VideoRecord | undefined {
  const db = loadDatabase();
  return db.videos.find((v) => v.id === id);
}

export function getVideos(opts: { limit?: number; offset?: number; search?: string; status?: string } = {}): { videos: VideoRecord[]; total: number } {
  const db = loadDatabase();
  const limit = opts.limit || 24;
  const offset = opts.offset || 0;
  const status = opts.status || "ready";

  let filtered = db.videos.filter((v) => v.status === status);
  
  if (opts.search) {
    const search = opts.search.toLowerCase();
    filtered = filtered.filter(
      (v) => v.title.toLowerCase().includes(search) || v.description.toLowerCase().includes(search)
    );
  }
  
  // Sort by created_at descending
  filtered.sort((a, b) => b.created_at.localeCompare(a.created_at));
  
  const total = filtered.length;
  const videos = filtered.slice(offset, offset + limit);
  
  return { videos, total };
}

export function deleteVideo(id: string): boolean {
  const db = loadDatabase();
  const index = db.videos.findIndex((v) => v.id === id);
  
  if (index === -1) return false;
  
  db.videos.splice(index, 1);
  saveDatabase();
  return true;
}

export function getAllVideosForAdmin(opts: { limit?: number; offset?: number } = {}): { videos: VideoRecord[]; total: number } {
  const db = loadDatabase();
  const limit = opts.limit || 50;
  const offset = opts.offset || 0;
  
  // Sort by created_at descending
  const sorted = [...db.videos].sort((a, b) => b.created_at.localeCompare(a.created_at));
  
  const total = sorted.length;
  const videos = sorted.slice(offset, offset + limit);
  
  return { videos, total };
}

// Check if database is accessible (for health check)
export function isDatabaseOk(): boolean {
  try {
    loadDatabase();
    return true;
  } catch {
    return false;
  }
}
