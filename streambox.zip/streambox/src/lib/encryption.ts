import crypto from "crypto";
import fs from "fs";
import path from "path";

// Encryption settings
const ALGORITHM = "aes-256-cbc";
const KEY_LENGTH = 32; // 256 bits
const IV_LENGTH = 16; // 128 bits

// Get or create encryption key
function getEncryptionKey(): Buffer {
  const keyPath = path.join(process.cwd(), "data", ".encryption_key");
  const keyDir = path.dirname(keyPath);
  
  if (!fs.existsSync(keyDir)) {
    fs.mkdirSync(keyDir, { recursive: true });
  }
  
  if (fs.existsSync(keyPath)) {
    return Buffer.from(fs.readFileSync(keyPath, "utf-8"), "hex");
  }
  
  // Generate new key
  const key = crypto.randomBytes(KEY_LENGTH);
  fs.writeFileSync(keyPath, key.toString("hex"), { mode: 0o600 });
  return key;
}

const ENCRYPTION_KEY = getEncryptionKey();

// Encrypt a file and save with .enc extension
export async function encryptFile(inputPath: string, outputPath: string): Promise<{ iv: string }> {
  return new Promise((resolve, reject) => {
    const iv = crypto.randomBytes(IV_LENGTH);
    const cipher = crypto.createCipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
    
    const input = fs.createReadStream(inputPath);
    const output = fs.createWriteStream(outputPath);
    
    // Write IV at the beginning of the file
    output.write(iv);
    
    input.pipe(cipher).pipe(output);
    
    output.on("finish", () => {
      resolve({ iv: iv.toString("hex") });
    });
    
    output.on("error", reject);
    input.on("error", reject);
  });
}

// Create a decryption stream for streaming
export function createDecryptStream(filePath: string): {
  stream: fs.ReadStream;
  decipher: crypto.Decipher;
  totalSize: number;
  encryptedSize: number;
} {
  const stats = fs.statSync(filePath);
  const encryptedSize = stats.size;
  
  // Read IV from file (first 16 bytes)
  const fd = fs.openSync(filePath, "r");
  const ivBuffer = Buffer.alloc(IV_LENGTH);
  fs.readSync(fd, ivBuffer, 0, IV_LENGTH, 0);
  fs.closeSync(fd);
  
  const decipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, ivBuffer);
  
  // Create stream starting after IV
  const stream = fs.createReadStream(filePath, { start: IV_LENGTH });
  
  // Approximate decrypted size (slightly less due to padding)
  const totalSize = encryptedSize - IV_LENGTH;
  
  return { stream, decipher, totalSize, encryptedSize };
}

// Decrypt specific byte range for Range requests
export async function decryptRange(
  filePath: string,
  start: number,
  end: number
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const stats = fs.statSync(filePath);
    const encryptedSize = stats.size - IV_LENGTH;
    
    // Read IV
    const fd = fs.openSync(filePath, "r");
    const ivBuffer = Buffer.alloc(IV_LENGTH);
    fs.readSync(fd, ivBuffer, 0, IV_LENGTH, 0);
    fs.closeSync(fd);
    
    // For AES-CBC, we need to decrypt from a block boundary
    const BLOCK_SIZE = 16;
    const blockStart = Math.floor(start / BLOCK_SIZE) * BLOCK_SIZE;
    const blockEnd = Math.min(Math.ceil((end + 1) / BLOCK_SIZE) * BLOCK_SIZE, encryptedSize);
    
    // Read encrypted data
    const encryptedStream = fs.createReadStream(filePath, {
      start: IV_LENGTH + blockStart,
      end: IV_LENGTH + blockEnd - 1,
    });
    
    const chunks: Buffer[] = [];
    
    // For range requests in middle of file, we need to use previous block as IV
    let iv = ivBuffer;
    if (blockStart > 0) {
      const prevBlockFd = fs.openSync(filePath, "r");
      const prevBlock = Buffer.alloc(BLOCK_SIZE);
      fs.readSync(prevBlockFd, prevBlock, 0, BLOCK_SIZE, IV_LENGTH + blockStart - BLOCK_SIZE);
      fs.closeSync(prevBlockFd);
      iv = prevBlock;
    }
    
    const decipher = crypto.createDecipheriv(ALGORITHM, ENCRYPTION_KEY, iv);
    decipher.setAutoPadding(false);
    
    encryptedStream.on("data", (chunk: Buffer | string) => {
      try {
        const buf = typeof chunk === "string" ? Buffer.from(chunk) : chunk;
        const decrypted = decipher.update(buf);
        chunks.push(decrypted);
      } catch (err) {
        reject(err);
      }
    });
    
    encryptedStream.on("end", () => {
      try {
        // Get the slice we actually need
        const fullDecrypted = Buffer.concat(chunks);
        const offsetStart = start - blockStart;
        const offsetEnd = offsetStart + (end - start + 1);
        const result = fullDecrypted.subarray(offsetStart, Math.min(offsetEnd, fullDecrypted.length));
        resolve(result);
      } catch (err) {
        reject(err);
      }
    });
    
    encryptedStream.on("error", reject);
  });
}

// Generate secure streaming token
export function generateStreamToken(videoId: string, expiresInSeconds: number = 300): string {
  const payload = {
    videoId,
    exp: Date.now() + expiresInSeconds * 1000,
    nonce: crypto.randomBytes(8).toString("hex"),
  };
  
  const data = JSON.stringify(payload);
  const cipher = crypto.createCipheriv(
    "aes-256-cbc",
    ENCRYPTION_KEY,
    Buffer.alloc(16, 0)
  );
  
  let encrypted = cipher.update(data, "utf8", "base64url");
  encrypted += cipher.final("base64url");
  
  return encrypted;
}

// Validate streaming token
export function validateStreamToken(token: string, videoId: string): boolean {
  try {
    const decipher = crypto.createDecipheriv(
      "aes-256-cbc",
      ENCRYPTION_KEY,
      Buffer.alloc(16, 0)
    );
    
    let decrypted = decipher.update(token, "base64url", "utf8");
    decrypted += decipher.final("utf8");
    
    const payload = JSON.parse(decrypted);
    
    if (payload.videoId !== videoId) return false;
    if (payload.exp < Date.now()) return false;
    
    return true;
  } catch {
    return false;
  }
}

// Generate session token for video access
export function generateSessionId(): string {
  return crypto.randomBytes(32).toString("hex");
}
