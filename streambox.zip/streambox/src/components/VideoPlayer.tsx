"use client";

import { useRef, useState, useEffect, useCallback } from "react";

interface VideoPlayerProps {
  videoId: string;
  title: string;
  onClose?: () => void;
}

function formatTime(sec: number): string {
  if (!sec || isNaN(sec)) return "0:00";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export default function VideoPlayer({ videoId, title }: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const hideTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const tokenRefreshInterval = useRef<ReturnType<typeof setInterval> | null>(null);
  const doubleTapTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showSpeedMenu, setShowSpeedMenu] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [streamToken, setStreamToken] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showSkipIndicator, setShowSkipIndicator] = useState<{ side: "left" | "right"; seconds: number } | null>(null);
  const [theaterMode, setTheaterMode] = useState(false);
  const [brightness, setBrightness] = useState(100);
  const [showKeyboardHelp, setShowKeyboardHelp] = useState(false);
  const [hoverTime, setHoverTime] = useState<number | null>(null);
  const [hoverPosition, setHoverPosition] = useState(0);

  // Fetch secure streaming token
  const fetchToken = useCallback(async () => {
    try {
      const res = await fetch(`/api/videos/${videoId}/token`, { credentials: "same-origin" });
      if (!res.ok) throw new Error("Failed to get access token");
      const data = await res.json();
      setStreamToken(data.token);
      setError(null);
      return data.token;
    } catch (err) {
      setError("Unable to access video");
      console.error("Token fetch error:", err);
      return null;
    }
  }, [videoId]);

  useEffect(() => {
    fetchToken();
    tokenRefreshInterval.current = setInterval(fetchToken, 240000);
    return () => {
      if (tokenRefreshInterval.current) clearInterval(tokenRefreshInterval.current);
    };
  }, [fetchToken]);

  useEffect(() => {
    if (streamToken && videoRef.current) {
      const currentTimeBeforeReload = videoRef.current.currentTime;
      const wasPlaying = !videoRef.current.paused;
      videoRef.current.src = `/api/videos/${videoId}/stream?token=${streamToken}`;
      videoRef.current.onloadedmetadata = () => {
        if (currentTimeBeforeReload > 0) videoRef.current!.currentTime = currentTimeBeforeReload;
        if (wasPlaying) videoRef.current!.play().catch(() => {});
      };
    }
  }, [streamToken, videoId]);

  const showControlsTemporarily = useCallback(() => {
    setShowControls(true);
    if (hideTimeout.current) clearTimeout(hideTimeout.current);
    hideTimeout.current = setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused) {
        setShowControls(false);
        setShowSpeedMenu(false);
        setShowSettings(false);
      }
    }, 3000);
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handlers = {
      play: () => setIsPlaying(true),
      pause: () => { setIsPlaying(false); setShowControls(true); },
      timeupdate: () => setCurrentTime(video.currentTime),
      durationchange: () => setDuration(video.duration),
      progress: () => { if (video.buffered.length > 0) setBuffered(video.buffered.end(video.buffered.length - 1)); },
      waiting: () => setIsLoading(true),
      canplay: () => setIsLoading(false),
      loadeddata: () => setIsLoading(false),
      error: () => { setError("Video playback error"); fetchToken(); },
    };

    Object.entries(handlers).forEach(([event, handler]) => video.addEventListener(event, handler));
    return () => Object.entries(handlers).forEach(([event, handler]) => video.removeEventListener(event, handler));
  }, [fetchToken]);

  useEffect(() => {
    const handleFsChange = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handleFsChange);
    return () => document.removeEventListener("fullscreenchange", handleFsChange);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      
      const video = videoRef.current;
      if (!video) return;

      switch (e.key.toLowerCase()) {
        case " ":
        case "k":
          e.preventDefault();
          video.paused ? video.play() : video.pause();
          break;
        case "f":
          e.preventDefault();
          toggleFullscreen();
          break;
        case "m":
          e.preventDefault();
          toggleMute();
          break;
        case "arrowleft":
        case "j":
          e.preventDefault();
          skip(-10);
          break;
        case "arrowright":
        case "l":
          e.preventDefault();
          skip(10);
          break;
        case "arrowup":
          e.preventDefault();
          setVolume(v => Math.min(1, v + 0.1));
          video.volume = Math.min(1, video.volume + 0.1);
          break;
        case "arrowdown":
          e.preventDefault();
          setVolume(v => Math.max(0, v - 0.1));
          video.volume = Math.max(0, video.volume - 0.1);
          break;
        case "0": case "1": case "2": case "3": case "4":
        case "5": case "6": case "7": case "8": case "9":
          e.preventDefault();
          video.currentTime = (parseInt(e.key) / 10) * video.duration;
          break;
        case "t":
          e.preventDefault();
          setTheaterMode(t => !t);
          break;
        case "?":
          e.preventDefault();
          setShowKeyboardHelp(h => !h);
          break;
        case "escape":
          setShowKeyboardHelp(false);
          setShowSettings(false);
          setShowSpeedMenu(false);
          break;
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Double tap to seek (mobile)
  const handleDoubleTap = (side: "left" | "right") => {
    const seconds = side === "left" ? -10 : 10;
    skip(seconds);
    setShowSkipIndicator({ side, seconds: Math.abs(seconds) });
    setTimeout(() => setShowSkipIndicator(null), 500);
  };

  let tapCount = 0;
  const handleContainerClick = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest(".controls-area")) return;
    
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    
    const x = e.clientX - rect.left;
    const side = x < rect.width / 3 ? "left" : x > (rect.width * 2) / 3 ? "right" : "center";
    
    tapCount++;
    if (tapCount === 1) {
      doubleTapTimeout.current = setTimeout(() => {
        if (tapCount === 1) togglePlay();
        tapCount = 0;
      }, 300);
    } else if (tapCount === 2) {
      if (doubleTapTimeout.current) clearTimeout(doubleTapTimeout.current);
      if (side !== "center") handleDoubleTap(side);
      tapCount = 0;
    }
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    video.paused ? video.play() : video.pause();
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const video = videoRef.current;
    const bar = progressRef.current;
    if (!video || !bar || !duration) return;
    const rect = bar.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    video.currentTime = pos * duration;
  };

  const handleProgressHover = (e: React.MouseEvent<HTMLDivElement>) => {
    const bar = progressRef.current;
    if (!bar || !duration) return;
    const rect = bar.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    setHoverTime(pos * duration);
    setHoverPosition(e.clientX - rect.left);
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const toggleFullscreen = async () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      await containerRef.current.requestFullscreen().catch(() => {});
    } else {
      await document.exitFullscreen().catch(() => {});
    }
  };

  const togglePiP = async () => {
    const video = videoRef.current;
    if (!video) return;
    try {
      if (document.pictureInPictureElement) await document.exitPictureInPicture();
      else await video.requestPictureInPicture();
    } catch {}
  };

  const changeSpeed = (rate: number) => {
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
      setPlaybackRate(rate);
    }
    setShowSpeedMenu(false);
  };

  const skip = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime = Math.max(0, Math.min(videoRef.current.currentTime + seconds, duration));
      setShowSkipIndicator({ side: seconds < 0 ? "left" : "right", seconds: Math.abs(seconds) });
      setTimeout(() => setShowSkipIndicator(null), 500);
    }
  };

  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
  const bufferProgress = duration > 0 ? (buffered / duration) * 100 : 0;

  if (error && !streamToken) {
    return (
      <div className={`relative bg-black w-full ${theaterMode ? 'h-screen' : 'aspect-video max-h-[80vh]'} rounded-2xl overflow-hidden flex items-center justify-center`}>
        <div className="text-center text-white p-8">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-red-500/20 flex items-center justify-center">
            <svg className="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <p className="text-lg font-medium mb-4">{error}</p>
          <button onClick={fetchToken} className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-xl font-medium hover:opacity-90 transition-opacity">
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={`video-container relative bg-black w-full ${theaterMode ? 'fixed inset-0 z-50' : 'aspect-video max-h-[80vh] rounded-2xl'} overflow-hidden group select-none`}
      style={{ filter: `brightness(${brightness}%)` }}
      onMouseMove={showControlsTemporarily}
      onTouchStart={showControlsTemporarily}
      onClick={handleContainerClick}
      onContextMenu={(e) => e.preventDefault()}
    >
      <video
        ref={videoRef}
        className="w-full h-full object-contain"
        title={title}
        preload="metadata"
        playsInline
        controlsList="nodownload noremoteplayback"
        onContextMenu={(e) => e.preventDefault()}
        draggable={false}
        crossOrigin="use-credentials"
      />

      {/* Skip indicators */}
      {showSkipIndicator && (
        <div className={`absolute top-1/2 -translate-y-1/2 ${showSkipIndicator.side === "left" ? "left-1/4" : "right-1/4"} flex flex-col items-center animate-pulse`}>
          <div className="w-16 h-16 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
            <svg className={`w-8 h-8 text-white ${showSkipIndicator.side === "left" ? "rotate-180" : ""}`} fill="currentColor" viewBox="0 0 24 24">
              <path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/>
            </svg>
          </div>
          <span className="text-white text-sm font-bold mt-2">{showSkipIndicator.seconds}s</span>
        </div>
      )}

      {/* Loading */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none bg-black/20">
          <div className="relative">
            <div className="w-16 h-16 border-4 border-purple-500/30 rounded-full" />
            <div className="absolute inset-0 w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin" />
          </div>
        </div>
      )}

      {/* Play button when paused */}
      {!isPlaying && !isLoading && streamToken && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="relative">
            <div className="absolute inset-0 bg-purple-600 rounded-full blur-2xl opacity-30 animate-pulse" />
            <div className="relative w-24 h-24 bg-gradient-to-br from-purple-600 via-purple-700 to-cyan-600 rounded-full flex items-center justify-center shadow-2xl">
              <svg className="w-10 h-10 text-white ml-2" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </div>
          </div>
        </div>
      )}

      {/* Security badge */}
      <div className={`absolute top-4 left-4 flex items-center gap-2 px-3 py-1.5 glass rounded-full transition-opacity duration-300 ${showControls ? 'opacity-100' : 'opacity-0'}`}>
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
        <span className="text-xs font-medium text-green-400">AES-256 Protected</span>
      </div>

      {/* Controls */}
      <div className={`controls-area absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black via-black/80 to-transparent pt-20 pb-4 px-4 transition-all duration-300 ${showControls ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
        {/* Progress bar */}
        <div
          ref={progressRef}
          className="relative h-1 bg-white/20 rounded-full cursor-pointer mb-4 group/prog hover:h-1.5 transition-all"
          onClick={(e) => { e.stopPropagation(); handleSeek(e); }}
          onMouseMove={handleProgressHover}
          onMouseLeave={() => setHoverTime(null)}
        >
          {/* Buffer */}
          <div className="absolute top-0 left-0 h-full bg-white/30 rounded-full" style={{ width: `${bufferProgress}%` }} />
          {/* Progress */}
          <div className="absolute top-0 left-0 h-full bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full progress-glow" style={{ width: `${progress}%` }} />
          {/* Thumb */}
          <div
            className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg scale-0 group-hover/prog:scale-100 transition-transform"
            style={{ left: `calc(${progress}% - 8px)` }}
          />
          {/* Hover preview */}
          {hoverTime !== null && (
            <div
              className="absolute bottom-6 px-2 py-1 bg-black/90 rounded text-xs text-white font-medium -translate-x-1/2 pointer-events-none"
              style={{ left: hoverPosition }}
            >
              {formatTime(hoverTime)}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1">
            {/* Play/Pause */}
            <button onClick={(e) => { e.stopPropagation(); togglePlay(); }} className="p-2.5 text-white hover:text-purple-400 transition-colors" aria-label="Play/Pause">
              {isPlaying ? (
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z"/></svg>
              ) : (
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
              )}
            </button>

            {/* Skip */}
            <button onClick={(e) => { e.stopPropagation(); skip(-10); }} className="p-2 text-white/70 hover:text-white transition-colors hidden sm:block" aria-label="Rewind">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M11 18V6l-8.5 6 8.5 6zm.5-6l8.5 6V6l-8.5 6z"/></svg>
            </button>
            <button onClick={(e) => { e.stopPropagation(); skip(10); }} className="p-2 text-white/70 hover:text-white transition-colors hidden sm:block" aria-label="Forward">
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M4 18l8.5-6L4 6v12zm9-12v12l8.5-6L13 6z"/></svg>
            </button>

            {/* Volume */}
            <div className="flex items-center group/vol">
              <button onClick={(e) => { e.stopPropagation(); toggleMute(); }} className="p-2 text-white/70 hover:text-white transition-colors" aria-label="Mute">
                {isMuted || volume === 0 ? (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>
                ) : (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
                )}
              </button>
              <input
                type="range" min="0" max="1" step="0.05" value={isMuted ? 0 : volume}
                onChange={(e) => { const v = parseFloat(e.target.value); setVolume(v); if (videoRef.current) { videoRef.current.volume = v; videoRef.current.muted = v === 0; setIsMuted(v === 0); } }}
                onClick={(e) => e.stopPropagation()}
                className="w-0 group-hover/vol:w-20 transition-all accent-purple-500 hidden sm:block"
              />
            </div>

            {/* Time */}
            <span className="text-xs text-white/70 ml-2 tabular-nums hidden sm:block">{formatTime(currentTime)} / {formatTime(duration)}</span>
          </div>

          <div className="flex items-center gap-1">
            {/* Speed */}
            <div className="relative">
              <button onClick={(e) => { e.stopPropagation(); setShowSpeedMenu(!showSpeedMenu); setShowSettings(false); }} className="px-2.5 py-1.5 text-xs text-white/70 hover:text-white font-medium rounded-lg hover:bg-white/10 transition-all">
                {playbackRate}x
              </button>
              {showSpeedMenu && (
                <div className="absolute bottom-full right-0 mb-2 py-1 glass rounded-xl min-w-[100px] overflow-hidden">
                  {[0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2].map((rate) => (
                    <button key={rate} onClick={(e) => { e.stopPropagation(); changeSpeed(rate); }} className={`block w-full text-left px-4 py-2 text-sm hover:bg-white/10 transition-colors ${playbackRate === rate ? "text-purple-400" : "text-white"}`}>
                      {rate}x
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Settings */}
            <div className="relative">
              <button onClick={(e) => { e.stopPropagation(); setShowSettings(!showSettings); setShowSpeedMenu(false); }} className="p-2 text-white/70 hover:text-white transition-colors" aria-label="Settings">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
              </button>
              {showSettings && (
                <div className="absolute bottom-full right-0 mb-2 py-2 glass rounded-xl w-56 overflow-hidden">
                  <div className="px-4 py-2">
                    <label className="text-xs text-gray-400 mb-2 block">Brightness</label>
                    <input type="range" min="50" max="150" value={brightness} onChange={(e) => setBrightness(parseInt(e.target.value))} className="w-full accent-purple-500" onClick={(e) => e.stopPropagation()} />
                  </div>
                  <button onClick={(e) => { e.stopPropagation(); setShowKeyboardHelp(true); setShowSettings(false); }} className="w-full text-left px-4 py-2 text-sm text-white hover:bg-white/10 flex items-center gap-2">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
                    Keyboard Shortcuts
                  </button>
                </div>
              )}
            </div>

            {/* PiP */}
            <button onClick={(e) => { e.stopPropagation(); togglePiP(); }} className="p-2 text-white/70 hover:text-white transition-colors hidden sm:block" aria-label="PiP">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2" strokeWidth={2}/><rect x="11" y="10" width="9" height="6" rx="1" strokeWidth={2}/></svg>
            </button>

            {/* Theater */}
            <button onClick={(e) => { e.stopPropagation(); setTheaterMode(!theaterMode); }} className="p-2 text-white/70 hover:text-white transition-colors hidden md:block" aria-label="Theater">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><rect x="2" y="4" width="20" height="16" rx="2" strokeWidth={2}/></svg>
            </button>

            {/* Fullscreen */}
            <button onClick={(e) => { e.stopPropagation(); toggleFullscreen(); }} className="p-2 text-white/70 hover:text-white transition-colors" aria-label="Fullscreen">
              {isFullscreen ? (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 9V6h3M6 15v3h3M18 9V6h-3M18 15v3h-3"/></svg>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V6a2 2 0 012-2h2M4 16v2a2 2 0 002 2h2M16 4h2a2 2 0 012 2v2M16 20h2a2 2 0 002-2v-2"/></svg>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Keyboard shortcuts modal */}
      {showKeyboardHelp && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50" onClick={() => setShowKeyboardHelp(false)}>
          <div className="glass p-6 rounded-2xl max-w-md w-full mx-4" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-white mb-4">Keyboard Shortcuts</h3>
            <div className="grid grid-cols-2 gap-3 text-sm">
              {[
                ["Space / K", "Play/Pause"],
                ["F", "Fullscreen"],
                ["M", "Mute"],
                ["J / ←", "Rewind 10s"],
                ["L / →", "Forward 10s"],
                ["↑ / ↓", "Volume"],
                ["0-9", "Seek %"],
                ["T", "Theater mode"],
                ["?", "Shortcuts"],
              ].map(([key, action]) => (
                <div key={key} className="flex items-center gap-2">
                  <kbd className="px-2 py-1 bg-white/10 rounded text-xs font-mono text-purple-400">{key}</kbd>
                  <span className="text-gray-400">{action}</span>
                </div>
              ))}
            </div>
            <button onClick={() => setShowKeyboardHelp(false)} className="mt-6 w-full py-2 bg-purple-600 hover:bg-purple-700 rounded-xl text-white font-medium transition-colors">
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
