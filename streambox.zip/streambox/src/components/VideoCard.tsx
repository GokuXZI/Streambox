"use client";

import Link from "next/link";
import { useState } from "react";

interface VideoCardProps {
  id: string;
  title: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
  thumbnail_path: string | null;
  file_size?: number;
}

function formatDuration(seconds: number | null): string {
  if (!seconds || seconds <= 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function getResLabel(h: number | null): string {
  if (!h) return "";
  if (h >= 2160) return "4K";
  if (h >= 1440) return "2K";
  if (h >= 1080) return "FHD";
  if (h >= 720) return "HD";
  return `${h}p`;
}

function timeAgo(dateStr: string): string {
  try {
    const date = new Date(dateStr.includes("Z") ? dateStr : dateStr + "Z");
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
    if (diff < 60) return "Just now";
    if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
    if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`;
    return `${Math.floor(diff / 604800)}w ago`;
  } catch {
    return "";
  }
}

export default function VideoCard({ id, title, duration, width, height, created_at }: VideoCardProps) {
  const [imgError, setImgError] = useState(false);
  const res = getResLabel(height);

  return (
    <Link href={`/watch/${id}`} className="block group">
      {/* Thumbnail */}
      <div className="relative aspect-video bg-[#1a1a24] rounded-xl overflow-hidden mb-3">
        {!imgError ? (
          <img
            src={`/api/videos/${id}/thumbnail`}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
            onError={() => setImgError(true)}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <svg className="w-12 h-12 text-gray-700" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
        )}

        {/* Duration */}
        {duration !== null && duration > 0 && (
          <span className="absolute bottom-2 right-2 px-1.5 py-0.5 bg-black/80 rounded text-xs font-medium text-white">
            {formatDuration(duration)}
          </span>
        )}

        {/* Resolution */}
        {res && (
          <span className="absolute top-2 right-2 px-1.5 py-0.5 bg-purple-600 rounded text-xs font-bold text-white">
            {res}
          </span>
        )}

        {/* Encrypted badge */}
        <span className="absolute top-2 left-2 flex items-center gap-1 px-1.5 py-0.5 bg-black/60 rounded text-[10px] text-green-400">
          <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
          Encrypted
        </span>

        {/* Play overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
          <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <svg className="w-5 h-5 text-white ml-0.5" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z"/>
            </svg>
          </div>
        </div>
      </div>

      {/* Info */}
      <h3 className="text-sm font-medium text-white line-clamp-2 mb-1 group-hover:text-purple-400 transition-colors">
        {title}
      </h3>
      <div className="flex items-center gap-2 text-xs text-gray-500">
        {width && height && <span>{width}×{height}</span>}
        <span>•</span>
        <span>{timeAgo(created_at)}</span>
      </div>
    </Link>
  );
}
