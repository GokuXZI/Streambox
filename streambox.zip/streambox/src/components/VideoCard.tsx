"use client";

import Link from "next/link";
import { useState, useRef, useEffect } from "react";

interface VideoCardProps {
  id: string;
  title: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
  thumbnail_path: string | null;
  file_size?: number;
  views?: number;
}

function formatDuration(seconds: number | null): string {
  if (!seconds || seconds <= 0) return "0:00";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function getResLabel(h: number | null): { label: string; color: string } {
  if (!h) return { label: "", color: "" };
  if (h >= 2160) return { label: "4K", color: "from-amber-500 to-orange-600" };
  if (h >= 1440) return { label: "2K", color: "from-purple-500 to-pink-600" };
  if (h >= 1080) return { label: "FHD", color: "from-cyan-500 to-blue-600" };
  if (h >= 720) return { label: "HD", color: "from-green-500 to-emerald-600" };
  return { label: `${h}p`, color: "from-gray-500 to-gray-600" };
}

function timeAgo(dateStr: string): string {
  const date = new Date(dateStr.includes("Z") ? dateStr : dateStr + "Z");
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  if (diffSec < 60) return "Just now";
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  const diffDay = Math.floor(diffHr / 24);
  if (diffDay < 7) return `${diffDay}d ago`;
  if (diffDay < 30) return `${Math.floor(diffDay / 7)}w ago`;
  const diffMonth = Math.floor(diffDay / 30);
  if (diffMonth < 12) return `${diffMonth}mo ago`;
  return `${Math.floor(diffMonth / 12)}y ago`;
}

function formatViews(views: number): string {
  if (views < 1000) return `${views} views`;
  if (views < 1000000) return `${(views / 1000).toFixed(1)}K views`;
  return `${(views / 1000000).toFixed(1)}M views`;
}

export default function VideoCard({ id, title, duration, width, height, created_at, file_size, views = 0 }: VideoCardProps) {
  const [imgError, setImgError] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const cardRef = useRef<HTMLAnchorElement>(null);
  const res = getResLabel(height);

  // Intersection observer for lazy loading
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1, rootMargin: "100px" }
    );

    if (cardRef.current) observer.observe(cardRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <Link
      ref={cardRef}
      href={`/watch/${id}`}
      className="group block relative"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Card glow effect */}
      <div className={`absolute -inset-2 bg-gradient-to-r from-purple-600/20 to-cyan-600/20 rounded-3xl blur-xl transition-opacity duration-500 ${isHovered ? 'opacity-100' : 'opacity-0'}`} />
      
      <div className="relative card-hover">
        {/* Thumbnail container */}
        <div className="relative aspect-video bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl overflow-hidden mb-4 ring-1 ring-white/5 group-hover:ring-purple-500/30 transition-all duration-500">
          {isVisible && !imgError ? (
            <img
              src={`/api/videos/${id}/thumbnail`}
              alt={title}
              className={`w-full h-full object-cover transition-all duration-700 ${isHovered ? 'scale-110 blur-[1px]' : 'scale-100'}`}
              loading="lazy"
              onError={() => setImgError(true)}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-purple-900/30 to-cyan-900/30">
              <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center">
                <svg className="w-8 h-8 text-gray-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z"/>
                </svg>
              </div>
            </div>
          )}

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-80 transition-opacity duration-300" />

          {/* Play button overlay */}
          <div className={`absolute inset-0 flex items-center justify-center transition-all duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}>
            <div className="relative">
              <div className="absolute inset-0 bg-purple-600 rounded-full blur-xl opacity-50 animate-pulse" />
              <div className="relative w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-800 rounded-full flex items-center justify-center shadow-2xl transform group-hover:scale-110 transition-transform">
                <svg className="w-7 h-7 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z"/>
                </svg>
              </div>
            </div>
          </div>

          {/* Duration badge */}
          {duration !== null && duration > 0 && (
            <div className="absolute bottom-3 right-3 px-2.5 py-1 bg-black/80 backdrop-blur-sm rounded-lg text-xs font-bold text-white tabular-nums tracking-wide">
              {formatDuration(duration)}
            </div>
          )}

          {/* Resolution badge */}
          {res.label && (
            <div className={`absolute top-3 right-3 px-2.5 py-1 bg-gradient-to-r ${res.color} rounded-lg text-xs font-bold text-white shadow-lg`}>
              {res.label}
            </div>
          )}

          {/* Encrypted badge */}
          <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2 py-1 bg-black/60 backdrop-blur-sm rounded-lg">
            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
            <span className="text-[10px] font-medium text-green-400 uppercase tracking-wider">Encrypted</span>
          </div>

          {/* Progress bar (if watched) */}
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10">
            <div className="h-full bg-gradient-to-r from-purple-600 to-cyan-500 w-0 group-hover:w-0" />
          </div>
        </div>

        {/* Info */}
        <div className="space-y-2 px-1">
          <h3 className="text-sm font-semibold text-white line-clamp-2 leading-snug group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-purple-400 group-hover:to-cyan-400 group-hover:bg-clip-text transition-all duration-300">
            {title}
          </h3>
          
          <div className="flex items-center gap-2 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {timeAgo(created_at)}
            </span>
            {width && height && (
              <>
                <span className="text-gray-700">•</span>
                <span>{width}×{height}</span>
              </>
            )}
            {views > 0 && (
              <>
                <span className="text-gray-700">•</span>
                <span>{formatViews(views)}</span>
              </>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
}
