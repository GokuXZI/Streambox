"use client";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="min-h-screen flex items-center justify-center px-4">
      <div className="gradient-bg" />
      <div className="relative text-center">
        <div className="absolute -top-20 left-1/2 -translate-x-1/2 w-64 h-64 bg-red-600/20 rounded-full blur-3xl" />
        
        <div className="relative mb-8">
          <div className="w-24 h-24 mx-auto glass rounded-full flex items-center justify-center">
            <svg className="w-12 h-12 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z" />
            </svg>
          </div>
        </div>
        
        <h1 className="text-2xl font-bold text-white mb-4">Something went wrong</h1>
        <p className="text-gray-500 mb-8 max-w-md mx-auto">{error.message || "An unexpected error occurred"}</p>
        
        <div className="flex items-center justify-center gap-4">
          <button onClick={reset} className="px-8 py-4 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-2xl text-white font-semibold hover:opacity-90 transition-opacity">
            Try Again
          </button>
          <a href="/" className="px-8 py-4 glass rounded-2xl text-gray-300 font-semibold hover:bg-white/10 transition-colors">
            Go Home
          </a>
        </div>
      </div>
    </div>
  );
}
