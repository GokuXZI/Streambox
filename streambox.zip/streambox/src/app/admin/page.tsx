"use client";

import { useEffect, useState, useRef } from "react";
import Link from "next/link";

interface Video {
  id: string;
  title: string;
  description: string;
  original_filename: string;
  status: string;
  file_size: number;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
}

function formatSize(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

function formatDur(seconds: number | null): string {
  if (!seconds) return "-";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export default function AdminPage() {
  const [token, setToken] = useState("");
  const [authed, setAuthed] = useState(false);
  const [authLoading, setAuthLoading] = useState(false);
  const [authError, setAuthError] = useState("");
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(false);

  // Upload
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadMessage, setUploadMessage] = useState("");
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadDesc, setUploadDesc] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Edit
  const [editId, setEditId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDesc, setEditDesc] = useState("");

  // Check saved token on mount
  useEffect(() => {
    const saved = localStorage.getItem("admin_token");
    if (saved) {
      setToken(saved);
      verifyToken(saved);
    }
  }, []);

  async function verifyToken(t: string) {
    if (!t.trim()) {
      setAuthError("Please enter a token");
      return;
    }
    
    setAuthLoading(true);
    setAuthError("");
    
    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: t.trim() }),
      });
      
      const data = await res.json();
      
      if (res.ok && data.success) {
        setAuthed(true);
        localStorage.setItem("admin_token", t.trim());
        fetchVideos(t.trim());
      } else {
        setAuthError(data.error || "Invalid token");
        localStorage.removeItem("admin_token");
      }
    } catch (err) {
      setAuthError("Connection error. Please try again.");
      console.error(err);
    } finally {
      setAuthLoading(false);
    }
  }

  async function fetchVideos(t?: string) {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/videos", {
        headers: { "x-admin-token": t || token },
      });
      if (res.ok) {
        const data = await res.json();
        setVideos(data.videos || []);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }

  async function handleUpload(e: React.FormEvent) {
    e.preventDefault();
    const file = fileInputRef.current?.files?.[0];
    if (!file) {
      setUploadMessage("Please select a video file");
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setUploadMessage("");

    const formData = new FormData();
    formData.append("video", file);
    formData.append("title", uploadTitle.trim());
    formData.append("description", uploadDesc.trim());

    try {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "/api/upload");
      xhr.setRequestHeader("x-admin-token", token);

      xhr.upload.onprogress = (ev) => {
        if (ev.lengthComputable) {
          setUploadProgress(Math.round((ev.loaded / ev.total) * 100));
        }
      };

      xhr.onload = () => {
        try {
          const result = JSON.parse(xhr.responseText);
          if (result.success) {
            setUploadMessage("✓ " + (result.message || "Upload successful"));
            setUploadTitle("");
            setUploadDesc("");
            if (fileInputRef.current) fileInputRef.current.value = "";
            fetchVideos();
          } else {
            setUploadMessage("✗ " + (result.error || "Upload failed"));
          }
        } catch {
          setUploadMessage("✗ Upload failed");
        }
        setUploading(false);
        setUploadProgress(0);
      };

      xhr.onerror = () => {
        setUploadMessage("✗ Upload failed");
        setUploading(false);
        setUploadProgress(0);
      };

      xhr.send(formData);
    } catch {
      setUploadMessage("✗ Upload failed");
      setUploading(false);
    }
  }

  async function handleDelete(id: string, title: string) {
    if (!confirm(`Delete "${title}"?`)) return;
    try {
      const res = await fetch(`/api/videos/${id}`, {
        method: "DELETE",
        headers: { "x-admin-token": token },
      });
      if (res.ok) {
        setVideos(videos.filter(v => v.id !== id));
      }
    } catch {
      alert("Delete failed");
    }
  }

  async function handleSaveEdit() {
    if (!editId) return;
    try {
      const res = await fetch(`/api/videos/${editId}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "x-admin-token": token,
        },
        body: JSON.stringify({ title: editTitle, description: editDesc }),
      });
      if (res.ok) {
        setEditId(null);
        fetchVideos();
      }
    } catch {
      alert("Update failed");
    }
  }

  function handleLogout() {
    setAuthed(false);
    setToken("");
    setVideos([]);
    localStorage.removeItem("admin_token");
  }

  // Login form
  if (!authed) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center p-4">
        <div className="w-full max-w-sm">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <h1 className="text-2xl font-bold text-white">Admin Login</h1>
            <p className="text-gray-500 mt-1">Enter your admin token</p>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); verifyToken(token); }} className="space-y-4">
            <input
              type="password"
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="Admin token"
              className="w-full px-4 py-3 bg-[#1a1a24] border border-[#2a2a35] rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
              autoFocus
              disabled={authLoading}
            />
            
            {authError && (
              <p className="text-red-400 text-sm">{authError}</p>
            )}
            
            <button
              type="submit"
              disabled={authLoading}
              className="w-full py-3 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-medium rounded-xl transition-colors"
            >
              {authLoading ? "Checking..." : "Login"}
            </button>
          </form>

          <div className="text-center mt-6">
            <Link href="/" className="text-gray-500 hover:text-white text-sm">
              ← Back to home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Admin panel
  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      {/* Header */}
      <header className="bg-[#111118] border-b border-[#1a1a24] px-4 py-3">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/" className="w-9 h-9 bg-purple-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z"/>
              </svg>
            </Link>
            <h1 className="text-lg font-bold text-white">Admin Panel</h1>
          </div>
          <button onClick={handleLogout} className="text-gray-400 hover:text-white text-sm">
            Logout
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto p-4">
        {/* Upload */}
        <div className="bg-[#111118] rounded-xl p-6 mb-6 border border-[#1a1a24]">
          <h2 className="text-lg font-bold text-white mb-4">Upload Video</h2>
          
          <form onSubmit={handleUpload} className="space-y-4">
            <div>
              <input
                ref={fileInputRef}
                type="file"
                accept="video/*,.mp4,.webm,.mkv,.mov,.avi"
                className="w-full text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:bg-purple-600 file:text-white hover:file:bg-purple-700 file:cursor-pointer"
                disabled={uploading}
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <input
                type="text"
                value={uploadTitle}
                onChange={(e) => setUploadTitle(e.target.value)}
                placeholder="Title (optional)"
                className="px-4 py-2.5 bg-[#1a1a24] border border-[#2a2a35] rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                disabled={uploading}
              />
              <input
                type="text"
                value={uploadDesc}
                onChange={(e) => setUploadDesc(e.target.value)}
                placeholder="Description (optional)"
                className="px-4 py-2.5 bg-[#1a1a24] border border-[#2a2a35] rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                disabled={uploading}
              />
            </div>

            {uploading && (
              <div>
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-gray-400">Uploading & encrypting...</span>
                  <span className="text-purple-400">{uploadProgress}%</span>
                </div>
                <div className="h-2 bg-[#1a1a24] rounded-full overflow-hidden">
                  <div className="h-full bg-purple-600 transition-all" style={{ width: `${uploadProgress}%` }} />
                </div>
              </div>
            )}

            {uploadMessage && (
              <p className={`text-sm ${uploadMessage.startsWith("✓") ? "text-green-400" : "text-red-400"}`}>
                {uploadMessage}
              </p>
            )}

            <button
              type="submit"
              disabled={uploading}
              className="px-6 py-2.5 bg-purple-600 hover:bg-purple-700 disabled:opacity-50 text-white font-medium rounded-lg transition-colors"
            >
              {uploading ? "Uploading..." : "Upload"}
            </button>
          </form>
        </div>

        {/* Videos */}
        <div className="bg-[#111118] rounded-xl border border-[#1a1a24]">
          <div className="px-6 py-4 border-b border-[#1a1a24] flex items-center justify-between">
            <h2 className="text-lg font-bold text-white">Videos ({videos.length})</h2>
            <button onClick={() => fetchVideos()} className="text-purple-400 hover:text-purple-300 text-sm">
              {loading ? "Loading..." : "Refresh"}
            </button>
          </div>

          {videos.length === 0 && !loading && (
            <div className="px-6 py-12 text-center text-gray-500">
              No videos yet.
            </div>
          )}

          <div className="divide-y divide-[#1a1a24]">
            {videos.map((video) => (
              <div key={video.id} className="px-6 py-4 flex flex-col sm:flex-row sm:items-center gap-4">
                {/* Thumbnail */}
                <Link href={`/watch/${video.id}`} className="w-full sm:w-32 shrink-0">
                  <div className="aspect-video bg-[#1a1a24] rounded-lg overflow-hidden">
                    <img
                      src={`/api/videos/${video.id}/thumbnail`}
                      alt=""
                      className="w-full h-full object-cover"
                      onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
                    />
                  </div>
                </Link>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-white truncate">{video.title}</h3>
                  <div className="flex flex-wrap gap-2 mt-1 text-xs text-gray-500">
                    <span>{formatSize(video.file_size)}</span>
                    <span>•</span>
                    <span>{formatDur(video.duration)}</span>
                    <span>•</span>
                    <span className={video.status === "ready" ? "text-green-400" : "text-yellow-400"}>
                      {video.status}
                    </span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button
                    onClick={() => { setEditId(video.id); setEditTitle(video.title); setEditDesc(video.description || ""); }}
                    className="px-3 py-1.5 bg-[#1a1a24] hover:bg-[#252530] text-white rounded-lg text-sm transition-colors"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDelete(video.id, video.title)}
                    className="px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg text-sm transition-colors"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Edit Modal */}
      {editId && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50" onClick={() => setEditId(null)}>
          <div className="bg-[#111118] rounded-xl p-6 w-full max-w-md border border-[#1a1a24]" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-white mb-4">Edit Video</h3>
            <div className="space-y-4">
              <input
                type="text"
                value={editTitle}
                onChange={(e) => setEditTitle(e.target.value)}
                placeholder="Title"
                className="w-full px-4 py-2.5 bg-[#1a1a24] border border-[#2a2a35] rounded-lg text-white focus:outline-none focus:border-purple-500"
              />
              <textarea
                value={editDesc}
                onChange={(e) => setEditDesc(e.target.value)}
                placeholder="Description"
                rows={3}
                className="w-full px-4 py-2.5 bg-[#1a1a24] border border-[#2a2a35] rounded-lg text-white focus:outline-none focus:border-purple-500 resize-none"
              />
              <div className="flex gap-3">
                <button onClick={() => setEditId(null)} className="flex-1 py-2.5 bg-[#1a1a24] text-white rounded-lg hover:bg-[#252530] transition-colors">
                  Cancel
                </button>
                <button onClick={handleSaveEdit} className="flex-1 py-2.5 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
