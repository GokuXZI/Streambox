"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import Link from "next/link";

interface Video {
  id: string;
  title: string;
  description: string;
  original_filename: string;
  status: string;
  file_size: number;
  duration: number | null;
  width: number | null;
  height: number | null;
  video_codec: string | null;
  audio_codec: string | null;
  created_at: string;
  thumbnail_path: string | null;
}

function formatSize(bytes: number): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
}

function formatDur(seconds: number | null): string {
  if (!seconds || seconds <= 0) return "-";
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  return `${m}:${String(s).padStart(2, "0")}`;
}

function resLabel(h: number | null): string {
  if (!h) return "-";
  if (h >= 2160) return "4K";
  if (h >= 1440) return "2K";
  if (h >= 1080) return "FHD";
  if (h >= 720) return "HD";
  return `${h}p`;
}

export default function AdminPage() {
  const [token, setToken] = useState("");
  const [authed, setAuthed] = useState(false);
  const [authError, setAuthError] = useState("");
  const [videos, setVideos] = useState<Video[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadMessage, setUploadMessage] = useState("");
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadDesc, setUploadDesc] = useState("");
  const [editId, setEditId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDesc, setEditDesc] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const savedToken = useCallback(() => typeof window !== "undefined" ? localStorage.getItem("admin_token") || "" : "", []);

  useEffect(() => {
    const t = savedToken();
    if (t) { setToken(t); verifyToken(t); }
  }, [savedToken]);

  async function verifyToken(t: string) {
    try {
      const res = await fetch("/api/admin/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: t }),
      });
      if (res.ok) {
        setAuthed(true);
        setAuthError("");
        localStorage.setItem("admin_token", t);
        fetchVideos(t);
      } else {
        setAuthError("Invalid admin token");
        setAuthed(false);
      }
    } catch { setAuthError("Connection error"); }
  }

  async function fetchVideos(t?: string) {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/videos", { headers: { "x-admin-token": t || token } });
      if (res.ok) setVideos((await res.json()).videos);
    } catch {} 
    finally { setLoading(false); }
  }

  async function handleUpload(file: File) {
    const allowedExts = [".mp4", ".webm", ".mkv", ".mov", ".avi", ".m4v", ".ogv", ".3gp"];
    const ext = file.name.toLowerCase().substring(file.name.lastIndexOf("."));
    if (!allowedExts.includes(ext)) {
      setUploadMessage("Invalid format. Supported: MP4, WebM, MKV, MOV, AVI");
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    setUploadMessage("");

    const formData = new FormData();
    formData.append("video", file);
    formData.append("title", uploadTitle.trim());
    formData.append("description", uploadDesc.trim());

    try {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "/api/upload");
      xhr.setRequestHeader("x-admin-token", token);
      xhr.upload.onprogress = (ev) => { if (ev.lengthComputable) setUploadProgress(Math.round((ev.loaded / ev.total) * 100)); };

      const result = await new Promise<{ success: boolean; message?: string; error?: string }>((resolve, reject) => {
        xhr.onload = () => { try { resolve(JSON.parse(xhr.responseText)); } catch { reject(new Error("Invalid response")); } };
        xhr.onerror = () => reject(new Error("Upload failed"));
        xhr.send(formData);
      });

      if (result.success) {
        setUploadMessage(`✓ ${result.message || "Uploaded & encrypted successfully"}`);
        setUploadTitle("");
        setUploadDesc("");
        if (fileInputRef.current) fileInputRef.current.value = "";
        fetchVideos();
      } else {
        setUploadMessage(`✗ ${result.error || "Upload failed"}`);
      }
    } catch (err) {
      setUploadMessage(`✗ ${err instanceof Error ? err.message : "Upload failed"}`);
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  }

  async function handleDelete(id: string, title: string) {
    if (!confirm(`Delete "${title}"? This cannot be undone.`)) return;
    try {
      const res = await fetch(`/api/videos/${id}`, { method: "DELETE", headers: { "x-admin-token": token } });
      if (res.ok) setVideos(videos.filter((v) => v.id !== id));
      else alert("Failed to delete");
    } catch { alert("Failed to delete"); }
  }

  async function handleSaveEdit() {
    if (!editId) return;
    try {
      const res = await fetch(`/api/videos/${editId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json", "x-admin-token": token },
        body: JSON.stringify({ title: editTitle, description: editDesc }),
      });
      if (res.ok) { setEditId(null); fetchVideos(); }
      else alert("Failed to update");
    } catch { alert("Failed to update"); }
  }

  const handleDrag = (e: React.DragEvent) => { e.preventDefault(); e.stopPropagation(); setDragActive(e.type === "dragenter" || e.type === "dragover"); };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files?.[0]) handleUpload(e.dataTransfer.files[0]);
  };

  // Stats
  const totalSize = videos.reduce((acc, v) => acc + (v.file_size || 0), 0);
  const totalDuration = videos.reduce((acc, v) => acc + (v.duration || 0), 0);
  const readyCount = videos.filter(v => v.status === "ready").length;

  if (!authed) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="gradient-bg" />
        <div className="w-full max-w-md relative">
          <div className="absolute -top-20 -left-20 w-40 h-40 bg-purple-600/30 rounded-full blur-3xl" />
          <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-cyan-600/30 rounded-full blur-3xl" />
          
          <div className="relative glass-strong rounded-3xl p-8">
            <div className="text-center mb-8">
              <div className="relative inline-block mb-4">
                <div className="absolute inset-0 bg-purple-600 rounded-2xl blur-xl opacity-50" />
                <div className="relative w-16 h-16 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-2xl flex items-center justify-center">
                  <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                </div>
              </div>
              <h1 className="text-2xl font-bold text-white mb-2">Admin Access</h1>
              <p className="text-gray-500 text-sm">Enter your admin token to continue</p>
            </div>

            <form onSubmit={(e) => { e.preventDefault(); verifyToken(token); }} className="space-y-4">
              <div className="relative">
                <input
                  type="password"
                  value={token}
                  onChange={(e) => setToken(e.target.value)}
                  placeholder="Enter admin token"
                  className="w-full px-5 py-4 bg-white/5 border border-white/10 rounded-2xl text-white placeholder-gray-600 focus:outline-none focus:border-purple-500/50 focus:bg-white/10 transition-all"
                  autoFocus
                />
              </div>
              {authError && <p className="text-red-400 text-sm text-center">{authError}</p>}
              <button type="submit" className="w-full py-4 bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-500 hover:to-cyan-500 text-white font-semibold rounded-2xl transition-all btn-shine">
                Unlock
              </button>
            </form>

            <div className="text-center mt-6">
              <Link href="/" className="text-sm text-gray-500 hover:text-white transition-colors">← Back to StreamVault</Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="gradient-bg" />
      
      {/* Admin header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass-strong">
        <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Link href="/" className="flex items-center gap-2">
                <div className="w-9 h-9 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-xl flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                </div>
              </Link>
              <div className="h-6 w-px bg-white/10" />
              <h1 className="text-lg font-bold text-white">Control Panel</h1>
            </div>
            <button onClick={() => { setAuthed(false); setToken(""); localStorage.removeItem("admin_token"); }} className="px-4 py-2 text-sm text-gray-400 hover:text-white transition-colors">
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="pt-24 pb-12 max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { label: "Total Videos", value: videos.length, icon: "🎬", gradient: "from-purple-600 to-pink-600" },
            { label: "Ready", value: readyCount, icon: "✅", gradient: "from-green-600 to-emerald-600" },
            { label: "Storage Used", value: formatSize(totalSize), icon: "💾", gradient: "from-cyan-600 to-blue-600" },
            { label: "Watch Time", value: `${Math.floor(totalDuration / 3600)}h ${Math.floor((totalDuration % 3600) / 60)}m`, icon: "⏱️", gradient: "from-orange-600 to-red-600" },
          ].map((stat) => (
            <div key={stat.label} className="glass rounded-2xl p-5 relative overflow-hidden group">
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-0 group-hover:opacity-10 transition-opacity`} />
              <div className="text-2xl mb-2">{stat.icon}</div>
              <div className="text-2xl font-bold text-white">{stat.value}</div>
              <div className="text-sm text-gray-500">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Upload Section */}
        <div className="glass rounded-3xl p-6 mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl" />
          
          <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
              </svg>
            </div>
            Upload Video
          </h2>

          <div
            className={`relative border-2 border-dashed rounded-2xl p-8 text-center transition-all ${dragActive ? "border-purple-500 bg-purple-500/10" : "border-white/10 hover:border-white/20"}`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="video/*,.mp4,.webm,.mkv,.mov,.avi,.m4v"
              onChange={(e) => e.target.files?.[0] && handleUpload(e.target.files[0])}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              disabled={uploading}
            />
            <div className="space-y-4">
              <div className="w-16 h-16 mx-auto bg-white/5 rounded-2xl flex items-center justify-center">
                <svg className="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
              </div>
              <div>
                <p className="text-white font-medium">Drop video here or click to browse</p>
                <p className="text-sm text-gray-500 mt-1">MP4, WebM, MKV, MOV, AVI • Max 4GB</p>
              </div>
            </div>
          </div>

          {/* Optional fields */}
          <div className="grid sm:grid-cols-2 gap-4 mt-4">
            <input
              type="text"
              value={uploadTitle}
              onChange={(e) => setUploadTitle(e.target.value)}
              placeholder="Title (optional)"
              className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-purple-500/50"
              disabled={uploading}
            />
            <input
              type="text"
              value={uploadDesc}
              onChange={(e) => setUploadDesc(e.target.value)}
              placeholder="Description (optional)"
              className="px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-gray-600 focus:outline-none focus:border-purple-500/50"
              disabled={uploading}
            />
          </div>

          {uploading && (
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-400">Encrypting & uploading...</span>
                <span className="text-purple-400 font-medium">{uploadProgress}%</span>
              </div>
              <div className="h-2 bg-white/10 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-purple-600 to-cyan-600 transition-all duration-300" style={{ width: `${uploadProgress}%` }} />
              </div>
            </div>
          )}

          {uploadMessage && (
            <div className={`mt-4 px-4 py-3 rounded-xl text-sm ${uploadMessage.startsWith("✓") ? "bg-green-500/20 text-green-400" : "bg-red-500/20 text-red-400"}`}>
              {uploadMessage}
            </div>
          )}
        </div>

        {/* Videos List */}
        <div className="glass rounded-3xl overflow-hidden">
          <div className="px-6 py-5 border-b border-white/5 flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Video Library</h2>
            <button onClick={() => fetchVideos()} disabled={loading} className="text-sm text-purple-400 hover:text-purple-300 transition-colors">
              {loading ? "Loading..." : "Refresh"}
            </button>
          </div>

          {videos.length === 0 && !loading && (
            <div className="px-6 py-16 text-center text-gray-500">
              <div className="w-16 h-16 mx-auto mb-4 bg-white/5 rounded-2xl flex items-center justify-center">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </div>
              <p>No videos yet. Upload your first video above.</p>
            </div>
          )}

          <div className="divide-y divide-white/5">
            {videos.map((video) => (
              <div key={video.id} className="px-6 py-4 flex flex-col sm:flex-row sm:items-center gap-4 hover:bg-white/[0.02] transition-colors">
                <Link href={`/watch/${video.id}`} className="w-full sm:w-40 shrink-0">
                  <div className="aspect-video bg-gradient-to-br from-gray-900 to-gray-800 rounded-xl overflow-hidden ring-1 ring-white/10">
                    <img src={`/api/videos/${video.id}/thumbnail`} alt="" className="w-full h-full object-cover" loading="lazy" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
                  </div>
                </Link>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-white truncate">{video.title}</h3>
                  <div className="flex flex-wrap gap-2 mt-2">
                    <span className="px-2 py-0.5 bg-white/5 rounded text-xs text-gray-400">{formatSize(video.file_size)}</span>
                    <span className="px-2 py-0.5 bg-white/5 rounded text-xs text-gray-400">{formatDur(video.duration)}</span>
                    <span className="px-2 py-0.5 bg-white/5 rounded text-xs text-gray-400">{resLabel(video.height)}</span>
                    <span className={`px-2 py-0.5 rounded text-xs font-medium ${video.status === "ready" ? "bg-green-500/20 text-green-400" : video.status === "error" ? "bg-red-500/20 text-red-400" : "bg-yellow-500/20 text-yellow-400"}`}>
                      {video.status}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 mt-1 truncate">{video.original_filename}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button onClick={() => { setEditId(video.id); setEditTitle(video.title); setEditDesc(video.description || ""); }} className="px-4 py-2 bg-white/5 hover:bg-white/10 text-gray-300 rounded-xl text-sm transition-colors">
                    Edit
                  </button>
                  <button onClick={() => handleDelete(video.id, video.title)} className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-xl text-sm transition-colors">
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Edit Modal */}
      {editId && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center px-4" onClick={() => setEditId(null)}>
          <div className="glass-strong rounded-3xl p-6 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-xl font-bold text-white mb-6">Edit Video</h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Title</label>
                <input type="text" value={editTitle} onChange={(e) => setEditTitle(e.target.value)} className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500/50" />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Description</label>
                <textarea value={editDesc} onChange={(e) => setEditDesc(e.target.value)} rows={4} className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-purple-500/50 resize-none" />
              </div>
              <div className="flex gap-3 pt-2">
                <button onClick={() => setEditId(null)} className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-gray-300 rounded-xl font-medium transition-colors">Cancel</button>
                <button onClick={handleSaveEdit} className="flex-1 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 text-white rounded-xl font-medium hover:opacity-90 transition-opacity">Save</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
