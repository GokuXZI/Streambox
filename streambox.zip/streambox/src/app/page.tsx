"use client";

import { useEffect, useState, useCallback } from "react";
import Header from "@/components/Header";
import VideoCard from "@/components/VideoCard";

interface Video {
  id: string;
  title: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
  thumbnail_path: string | null;
  file_size: number;
}

interface VideosResponse {
  videos: Video[];
  total: number;
  page: number;
  totalPages: number;
}

type SortOption = "newest" | "oldest" | "longest" | "shortest";

export default function HomePage() {
  const [data, setData] = useState<VideosResponse | null>(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [sortBy, setSortBy] = useState<SortOption>("newest");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const fetchVideos = useCallback(async (p: number) => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/videos?page=${p}&limit=24`);
      if (!res.ok) throw new Error("Failed to load videos");
      const json = await res.json();
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchVideos(page);
  }, [page, fetchVideos]);

  // Sort videos
  const sortedVideos = data?.videos ? [...data.videos].sort((a, b) => {
    switch (sortBy) {
      case "oldest": return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
      case "longest": return (b.duration || 0) - (a.duration || 0);
      case "shortest": return (a.duration || 0) - (b.duration || 0);
      default: return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    }
  }) : [];

  // Stats
  const totalDuration = data?.videos?.reduce((acc, v) => acc + (v.duration || 0), 0) || 0;
  const totalSize = data?.videos?.reduce((acc, v) => acc + (v.file_size || 0), 0) || 0;

  return (
    <div className="min-h-screen page-transition">
      <Header />
      
      <main className="pt-24 pb-12">
        {/* Hero Section */}
        <section className="relative overflow-hidden">
          <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
            <div className="relative">
              {/* Background decoration */}
              <div className="absolute -top-20 -left-20 w-72 h-72 bg-purple-600/20 rounded-full blur-3xl" />
              <div className="absolute -bottom-20 -right-20 w-72 h-72 bg-cyan-600/20 rounded-full blur-3xl" />
              
              <div className="relative text-center max-w-4xl mx-auto">
                <div className="inline-flex items-center gap-2 px-4 py-2 glass rounded-full mb-6">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm text-gray-400">AES-256 Encrypted Streaming</span>
                </div>
                
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-6">
                  <span className="bg-gradient-to-r from-white via-purple-200 to-cyan-200 bg-clip-text text-transparent">
                    Your Private
                  </span>
                  <br />
                  <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent glow-text">
                    Video Vault
                  </span>
                </h1>
                
                <p className="text-lg text-gray-400 mb-10 max-w-2xl mx-auto">
                  Secure, encrypted video streaming with military-grade protection. 
                  Your content stays private, always.
                </p>

                {/* Stats */}
                {data && data.total > 0 && (
                  <div className="flex flex-wrap items-center justify-center gap-6 sm:gap-12">
                    <div className="text-center">
                      <div className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                        {data.total}
                      </div>
                      <div className="text-sm text-gray-500 mt-1">Videos</div>
                    </div>
                    <div className="w-px h-12 bg-gradient-to-b from-transparent via-gray-700 to-transparent hidden sm:block" />
                    <div className="text-center">
                      <div className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-cyan-400 to-green-400 bg-clip-text text-transparent">
                        {Math.floor(totalDuration / 3600)}h {Math.floor((totalDuration % 3600) / 60)}m
                      </div>
                      <div className="text-sm text-gray-500 mt-1">Watch Time</div>
                    </div>
                    <div className="w-px h-12 bg-gradient-to-b from-transparent via-gray-700 to-transparent hidden sm:block" />
                    <div className="text-center">
                      <div className="text-3xl sm:text-4xl font-black bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                        {(totalSize / (1024 * 1024 * 1024)).toFixed(1)}GB
                      </div>
                      <div className="text-sm text-gray-500 mt-1">Storage</div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
          {/* Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-4">
              <h2 className="text-xl font-bold text-white">All Videos</h2>
              {data && (
                <span className="px-3 py-1 glass rounded-full text-sm text-gray-400">
                  {data.total} videos
                </span>
              )}
            </div>

            <div className="flex items-center gap-3">
              {/* Sort */}
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as SortOption)}
                className="px-4 py-2.5 glass rounded-xl text-sm text-white bg-transparent border-0 focus:outline-none focus:ring-2 focus:ring-purple-500/50 cursor-pointer"
              >
                <option value="newest" className="bg-gray-900">Newest First</option>
                <option value="oldest" className="bg-gray-900">Oldest First</option>
                <option value="longest" className="bg-gray-900">Longest</option>
                <option value="shortest" className="bg-gray-900">Shortest</option>
              </select>

              {/* View mode */}
              <div className="flex glass rounded-xl overflow-hidden">
                <button
                  onClick={() => setViewMode("grid")}
                  className={`p-2.5 transition-colors ${viewMode === "grid" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"}`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                  </svg>
                </button>
                <button
                  onClick={() => setViewMode("list")}
                  className={`p-2.5 transition-colors ${viewMode === "list" ? "bg-purple-600 text-white" : "text-gray-400 hover:text-white"}`}
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                  </svg>
                </button>
              </div>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div className="glass border border-red-500/30 text-red-400 px-6 py-4 rounded-2xl mb-8 flex items-center gap-3">
              <svg className="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {error}
            </div>
          )}

          {/* Loading skeleton */}
          {loading && !data && (
            <div className={`grid gap-6 ${viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5" : "grid-cols-1"}`}>
              {Array.from({ length: 10 }).map((_, i) => (
                <div key={i} className="space-y-4">
                  <div className="aspect-video skeleton rounded-2xl" />
                  <div className="space-y-2 px-1">
                    <div className="h-4 skeleton rounded w-3/4" />
                    <div className="h-3 skeleton rounded w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Empty state */}
          {data && data.videos.length === 0 && !loading && (
            <div className="text-center py-24">
              <div className="relative inline-block mb-8">
                <div className="absolute inset-0 bg-purple-600/20 rounded-full blur-3xl" />
                <div className="relative w-32 h-32 glass rounded-full flex items-center justify-center">
                  <svg className="w-16 h-16 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                </div>
              </div>
              <h2 className="text-2xl font-bold text-white mb-3">No Videos Yet</h2>
              <p className="text-gray-500 mb-8 max-w-md mx-auto">
                Upload your first video through the admin panel to start building your private collection.
              </p>
              <a href="/admin" className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-xl text-white font-medium hover:opacity-90 transition-opacity btn-shine">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Upload Video
              </a>
            </div>
          )}

          {/* Video grid */}
          {data && sortedVideos.length > 0 && (
            <>
              <div className={`grid gap-6 ${viewMode === "grid" ? "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5" : "grid-cols-1 max-w-4xl"}`}>
                {sortedVideos.map((video) => (
                  <VideoCard key={video.id} {...video} />
                ))}
              </div>

              {/* Pagination */}
              {data.totalPages > 1 && (
                <div className="flex items-center justify-center gap-2 mt-12">
                  <button
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={page <= 1}
                    className="px-5 py-2.5 glass rounded-xl text-white disabled:opacity-40 hover:bg-white/10 transition-all text-sm font-medium disabled:cursor-not-allowed"
                  >
                    ← Previous
                  </button>
                  
                  <div className="flex items-center gap-1">
                    {Array.from({ length: Math.min(5, data.totalPages) }).map((_, i) => {
                      const pageNum = i + 1;
                      return (
                        <button
                          key={pageNum}
                          onClick={() => setPage(pageNum)}
                          className={`w-10 h-10 rounded-xl text-sm font-medium transition-all ${
                            page === pageNum
                              ? "bg-gradient-to-r from-purple-600 to-cyan-600 text-white"
                              : "glass text-gray-400 hover:text-white hover:bg-white/10"
                          }`}
                        >
                          {pageNum}
                        </button>
                      );
                    })}
                  </div>

                  <button
                    onClick={() => setPage((p) => Math.min(data.totalPages, p + 1))}
                    disabled={page >= data.totalPages}
                    className="px-5 py-2.5 glass rounded-xl text-white disabled:opacity-40 hover:bg-white/10 transition-all text-sm font-medium disabled:cursor-not-allowed"
                  >
                    Next →
                  </button>
                </div>
              )}
            </>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 py-8 mt-12">
        <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-purple-600 to-cyan-600 rounded-lg flex items-center justify-center">
                <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M8 5v14l11-7z"/>
                </svg>
              </div>
              <span className="text-sm text-gray-500">StreamVault • Encrypted Video Platform</span>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <span>AES-256 Encryption</span>
              <span>•</span>
              <span>Token Authentication</span>
              <span>•</span>
              <span>Zero Third-Party</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
