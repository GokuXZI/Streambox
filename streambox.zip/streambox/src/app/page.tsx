"use client";

import { useEffect, useState, useCallback } from "react";
import Header from "@/components/Header";
import VideoCard from "@/components/VideoCard";

interface Video {
  id: string;
  title: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
  thumbnail_path: string | null;
  file_size: number;
}

interface VideosResponse {
  videos: Video[];
  total: number;
  page: number;
  totalPages: number;
}

export default function HomePage() {
  const [data, setData] = useState<VideosResponse | null>(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchVideos = useCallback(async (p: number) => {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/videos?page=${p}&limit=24`);
      if (!res.ok) throw new Error("Failed to load videos");
      setData(await res.json());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchVideos(page);
  }, [page, fetchVideos]);

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Header />
      
      <main className="pt-20 pb-12 px-4 max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white">Videos</h1>
            {data && <p className="text-sm text-gray-500">{data.total} videos</p>}
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Loading */}
        {loading && !data && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i}>
                <div className="aspect-video skeleton rounded-xl mb-3" />
                <div className="h-4 skeleton rounded w-3/4 mb-2" />
                <div className="h-3 skeleton rounded w-1/2" />
              </div>
            ))}
          </div>
        )}

        {/* Empty */}
        {data && data.videos.length === 0 && !loading && (
          <div className="text-center py-20">
            <div className="w-20 h-20 bg-[#1a1a24] rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
            </div>
            <h2 className="text-xl font-bold text-white mb-2">No Videos Yet</h2>
            <p className="text-gray-500 mb-6">Upload your first video through the admin panel.</p>
            <a href="/admin" className="inline-block px-6 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors">
              Go to Admin
            </a>
          </div>
        )}

        {/* Videos Grid */}
        {data && data.videos.length > 0 && (
          <>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {data.videos.map((video) => (
                <VideoCard key={video.id} {...video} />
              ))}
            </div>

            {/* Pagination */}
            {data.totalPages > 1 && (
              <div className="flex items-center justify-center gap-4 mt-10">
                <button
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  disabled={page <= 1}
                  className="px-4 py-2 bg-[#1a1a24] text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#252530] transition-colors"
                >
                  Previous
                </button>
                <span className="text-gray-400">
                  Page {page} of {data.totalPages}
                </span>
                <button
                  onClick={() => setPage(p => Math.min(data.totalPages, p + 1))}
                  disabled={page >= data.totalPages}
                  className="px-4 py-2 bg-[#1a1a24] text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-[#252530] transition-colors"
                >
                  Next
                </button>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
