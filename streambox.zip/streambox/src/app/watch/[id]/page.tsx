"use client";

import { useEffect, useState, use } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import VideoPlayer from "@/components/VideoPlayer";
import VideoCard from "@/components/VideoCard";

interface VideoDetail {
  id: string;
  title: string;
  description: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  file_size: number;
  video_codec: string | null;
  audio_codec: string | null;
  container_format: string | null;
  fps: number | null;
  bitrate: number | null;
  created_at: string;
  resolution_label: string;
  duration_formatted: string;
  file_size_formatted: string;
  thumbnail_path: string | null;
}

interface RelatedVideo {
  id: string;
  title: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
  thumbnail_path: string | null;
  file_size: number;
}

function formatDate(dateStr: string): string {
  try {
    const d = new Date(dateStr.includes("Z") ? dateStr : dateStr + "Z");
    return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  } catch {
    return dateStr;
  }
}

export default function WatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [video, setVideo] = useState<VideoDetail | null>(null);
  const [related, setRelated] = useState<RelatedVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showInfo, setShowInfo] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError("");
      try {
        const res = await fetch(`/api/videos/${id}`);
        if (!res.ok) {
          if (res.status === 404) throw new Error("Video not found");
          throw new Error("Failed to load video");
        }
        const data = await res.json();
        setVideo(data);

        const relRes = await fetch(`/api/videos?limit=8`);
        if (relRes.ok) {
          const relData = await relRes.json();
          setRelated(relData.videos.filter((v: RelatedVideo) => v.id !== id).slice(0, 6));
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Something went wrong");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="aspect-video skeleton rounded-2xl mb-6 max-w-5xl" />
          <div className="h-8 skeleton rounded-xl w-1/2 mb-3" />
          <div className="h-4 skeleton rounded w-1/3" />
        </main>
      </div>
    );
  }

  if (error || !video) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-24 max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <div className="relative inline-block mb-8">
            <div className="absolute inset-0 bg-red-600/20 rounded-full blur-3xl" />
            <div className="relative w-24 h-24 glass rounded-full flex items-center justify-center">
              <svg className="w-12 h-12 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
          </div>
          <h1 className="text-2xl font-bold text-white mb-4">{error || "Video not found"}</h1>
          <Link href="/" className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 rounded-xl text-white font-medium hover:opacity-90 transition-opacity">
            ← Back to Home
          </Link>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen page-transition">
      <Header />
      
      <main className="pt-24 pb-12">
        <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col xl:flex-row gap-8">
            {/* Main content */}
            <div className="flex-1 min-w-0">
              <VideoPlayer videoId={video.id} title={video.title} />

              {/* Video info */}
              <div className="mt-6">
                <h1 className="text-2xl sm:text-3xl font-bold text-white mb-4">{video.title}</h1>

                {/* Meta & Actions */}
                <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                  <div className="flex flex-wrap items-center gap-3">
                    <span className="px-3 py-1.5 glass rounded-lg text-sm text-purple-400 font-medium">
                      {video.resolution_label}
                    </span>
                    <span className="px-3 py-1.5 glass rounded-lg text-sm text-cyan-400 font-medium">
                      {video.duration_formatted}
                    </span>
                    <span className="px-3 py-1.5 glass rounded-lg text-sm text-gray-400">
                      {video.file_size_formatted}
                    </span>
                    <span className="text-sm text-gray-500">
                      {formatDate(video.created_at)}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={copyLink}
                      className="flex items-center gap-2 px-4 py-2 glass rounded-xl text-sm text-gray-400 hover:text-white transition-colors"
                    >
                      {copied ? (
                        <>
                          <svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                          Copied!
                        </>
                      ) : (
                        <>
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                          </svg>
                          Share
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Description */}
                {video.description && (
                  <div className="glass rounded-2xl p-5 mb-6">
                    <p className="text-gray-300 whitespace-pre-wrap leading-relaxed">{video.description}</p>
                  </div>
                )}

                {/* Technical details */}
                <button
                  onClick={() => setShowInfo(!showInfo)}
                  className="flex items-center gap-2 text-sm text-purple-400 hover:text-purple-300 transition-colors mb-4"
                >
                  <svg className={`w-4 h-4 transition-transform ${showInfo ? "rotate-180" : ""}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                  Technical Details
                </button>

                {showInfo && (
                  <div className="glass rounded-2xl p-5 mb-6">
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                      {video.width && video.height && (
                        <div className="space-y-1">
                          <div className="text-xs text-gray-500 uppercase tracking-wider">Resolution</div>
                          <div className="text-white font-medium">{video.width}×{video.height}</div>
                        </div>
                      )}
                      {video.video_codec && (
                        <div className="space-y-1">
                          <div className="text-xs text-gray-500 uppercase tracking-wider">Video Codec</div>
                          <div className="text-white font-medium uppercase">{video.video_codec}</div>
                        </div>
                      )}
                      {video.audio_codec && (
                        <div className="space-y-1">
                          <div className="text-xs text-gray-500 uppercase tracking-wider">Audio Codec</div>
                          <div className="text-white font-medium uppercase">{video.audio_codec}</div>
                        </div>
                      )}
                      {video.container_format && (
                        <div className="space-y-1">
                          <div className="text-xs text-gray-500 uppercase tracking-wider">Container</div>
                          <div className="text-white font-medium uppercase">{video.container_format}</div>
                        </div>
                      )}
                      {video.fps && (
                        <div className="space-y-1">
                          <div className="text-xs text-gray-500 uppercase tracking-wider">Frame Rate</div>
                          <div className="text-white font-medium">{video.fps} FPS</div>
                        </div>
                      )}
                      {video.bitrate && (
                        <div className="space-y-1">
                          <div className="text-xs text-gray-500 uppercase tracking-wider">Bitrate</div>
                          <div className="text-white font-medium">{Math.round(video.bitrate / 1000)} kbps</div>
                        </div>
                      )}
                      <div className="space-y-1">
                        <div className="text-xs text-gray-500 uppercase tracking-wider">Encryption</div>
                        <div className="text-green-400 font-medium">AES-256-CBC</div>
                      </div>
                      <div className="space-y-1">
                        <div className="text-xs text-gray-500 uppercase tracking-wider">Protection</div>
                        <div className="text-green-400 font-medium">Token Auth</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar */}
            {related.length > 0 && (
              <div className="xl:w-96 shrink-0">
                <div className="sticky top-28">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-lg font-bold text-white">More Videos</h2>
                    <Link href="/" className="text-sm text-purple-400 hover:text-purple-300 transition-colors">
                      View All →
                    </Link>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-1 gap-4">
                    {related.map((v) => (
                      <VideoCard key={v.id} {...v} />
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
