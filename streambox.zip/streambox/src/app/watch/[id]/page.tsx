"use client";

import { useEffect, useState, use } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import VideoPlayer from "@/components/VideoPlayer";
import VideoCard from "@/components/VideoCard";

interface VideoDetail {
  id: string;
  title: string;
  description: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  file_size: number;
  video_codec: string | null;
  audio_codec: string | null;
  created_at: string;
  resolution_label: string;
  duration_formatted: string;
  file_size_formatted: string;
}

interface RelatedVideo {
  id: string;
  title: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
  thumbnail_path: string | null;
  file_size: number;
}

export default function WatchPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [video, setVideo] = useState<VideoDetail | null>(null);
  const [related, setRelated] = useState<RelatedVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const res = await fetch(`/api/videos/${id}`);
        if (!res.ok) throw new Error(res.status === 404 ? "Video not found" : "Failed to load");
        setVideo(await res.json());

        const relRes = await fetch("/api/videos?limit=6");
        if (relRes.ok) {
          const data = await relRes.json();
          setRelated(data.videos.filter((v: RelatedVideo) => v.id !== id));
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Error");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f]">
        <Header />
        <main className="pt-20 px-4 max-w-6xl mx-auto">
          <div className="aspect-video skeleton rounded-xl mb-4" />
          <div className="h-6 skeleton rounded w-1/2 mb-2" />
          <div className="h-4 skeleton rounded w-1/3" />
        </main>
      </div>
    );
  }

  if (error || !video) {
    return (
      <div className="min-h-screen bg-[#0a0a0f]">
        <Header />
        <main className="pt-20 px-4 max-w-6xl mx-auto text-center py-20">
          <div className="w-20 h-20 bg-[#1a1a24] rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-10 h-10 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h1 className="text-xl font-bold text-white mb-2">{error || "Video not found"}</h1>
          <Link href="/" className="text-purple-400 hover:underline">← Back to home</Link>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Header />
      
      <main className="pt-20 pb-12 px-4 max-w-6xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Video */}
          <div className="flex-1">
            <VideoPlayer videoId={video.id} title={video.title} />
            
            <div className="mt-4">
              <h1 className="text-xl font-bold text-white mb-2">{video.title}</h1>
              
              <div className="flex flex-wrap gap-2 text-sm text-gray-400 mb-4">
                <span className="px-2 py-1 bg-[#1a1a24] rounded">{video.resolution_label}</span>
                <span className="px-2 py-1 bg-[#1a1a24] rounded">{video.duration_formatted}</span>
                <span className="px-2 py-1 bg-[#1a1a24] rounded">{video.file_size_formatted}</span>
              </div>

              {video.description && (
                <div className="bg-[#111118] rounded-lg p-4 text-gray-300 text-sm whitespace-pre-wrap">
                  {video.description}
                </div>
              )}
            </div>
          </div>

          {/* Related */}
          {related.length > 0 && (
            <div className="lg:w-80 shrink-0">
              <h2 className="text-lg font-bold text-white mb-4">More Videos</h2>
              <div className="space-y-4">
                {related.slice(0, 5).map((v) => (
                  <VideoCard key={v.id} {...v} />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
