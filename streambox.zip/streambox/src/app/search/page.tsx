"use client";

import { useEffect, useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Header from "@/components/Header";
import VideoCard from "@/components/VideoCard";

interface Video {
  id: string;
  title: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
  thumbnail_path: string | null;
  file_size: number;
}

function SearchResults() {
  const searchParams = useSearchParams();
  const query = searchParams.get("q") || "";
  const [videos, setVideos] = useState<Video[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query.trim()) return;
    
    setLoading(true);
    fetch(`/api/videos?search=${encodeURIComponent(query)}&limit=24`)
      .then(res => res.json())
      .then(data => {
        setVideos(data.videos || []);
        setTotal(data.total || 0);
      })
      .finally(() => setLoading(false));
  }, [query]);

  return (
    <main className="pt-20 pb-12 px-4 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-bold text-white">
          Results for &ldquo;{query}&rdquo;
        </h1>
        <p className="text-sm text-gray-500">{total} videos found</p>
      </div>

      {loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i}>
              <div className="aspect-video skeleton rounded-xl mb-3" />
              <div className="h-4 skeleton rounded w-3/4 mb-2" />
              <div className="h-3 skeleton rounded w-1/2" />
            </div>
          ))}
        </div>
      )}

      {!loading && videos.length === 0 && (
        <div className="text-center py-20">
          <div className="w-16 h-16 bg-[#1a1a24] rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <h2 className="text-lg font-bold text-white mb-2">No results</h2>
          <p className="text-gray-500">Try different keywords</p>
        </div>
      )}

      {!loading && videos.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {videos.map((video) => (
            <VideoCard key={video.id} {...video} />
          ))}
        </div>
      )}
    </main>
  );
}

export default function SearchPage() {
  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Header />
      <Suspense fallback={
        <main className="pt-20 px-4 max-w-7xl mx-auto">
          <div className="h-6 skeleton rounded w-1/3 mb-6" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i}>
                <div className="aspect-video skeleton rounded-xl mb-3" />
                <div className="h-4 skeleton rounded w-3/4" />
              </div>
            ))}
          </div>
        </main>
      }>
        <SearchResults />
      </Suspense>
    </div>
  );
}
