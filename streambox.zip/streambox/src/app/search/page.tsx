"use client";

import { useEffect, useState, useCallback, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Header from "@/components/Header";
import VideoCard from "@/components/VideoCard";

interface Video {
  id: string;
  title: string;
  duration: number | null;
  width: number | null;
  height: number | null;
  created_at: string;
  thumbnail_path: string | null;
  file_size: number;
}

interface SearchResult {
  videos: Video[];
  total: number;
  page: number;
  totalPages: number;
}

function SearchContent() {
  const searchParams = useSearchParams();
  const query = searchParams.get("q") || "";
  const [data, setData] = useState<SearchResult | null>(null);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);

  const search = useCallback(async (q: string, p: number) => {
    if (!q.trim()) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/videos?search=${encodeURIComponent(q)}&page=${p}&limit=24`);
      if (res.ok) setData(await res.json());
    } catch {} 
    finally { setLoading(false); }
  }, []);

  useEffect(() => { setPage(1); search(query, 1); }, [query, search]);
  useEffect(() => { if (page > 1) search(query, page); }, [page, query, search]);

  return (
    <main className="pt-24 pb-12 max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">
          Search results for{" "}
          <span className="bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
            &ldquo;{query}&rdquo;
          </span>
        </h1>
        {data && <p className="text-gray-500">{data.total} video{data.total !== 1 ? "s" : ""} found</p>}
      </div>

      {loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="space-y-4">
              <div className="aspect-video skeleton rounded-2xl" />
              <div className="h-4 skeleton rounded w-3/4" />
              <div className="h-3 skeleton rounded w-1/2" />
            </div>
          ))}
        </div>
      )}

      {!loading && data && data.videos.length === 0 && (
        <div className="text-center py-20">
          <div className="w-20 h-20 glass rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <h2 className="text-xl font-bold text-white mb-2">No results found</h2>
          <p className="text-gray-500">Try different search terms</p>
        </div>
      )}

      {!loading && data && data.videos.length > 0 && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {data.videos.map((video) => <VideoCard key={video.id} {...video} />)}
          </div>

          {data.totalPages > 1 && (
            <div className="flex items-center justify-center gap-3 mt-12">
              <button
                onClick={() => setPage((p) => Math.max(1, p - 1))}
                disabled={page <= 1}
                className="px-5 py-2.5 glass rounded-xl text-white disabled:opacity-40 transition-all text-sm font-medium"
              >
                ← Previous
              </button>
              <span className="px-4 py-2 text-gray-400">Page {data.page} of {data.totalPages}</span>
              <button
                onClick={() => setPage((p) => Math.min(data.totalPages, p + 1))}
                disabled={page >= data.totalPages}
                className="px-5 py-2.5 glass rounded-xl text-white disabled:opacity-40 transition-all text-sm font-medium"
              >
                Next →
              </button>
            </div>
          )}
        </>
      )}
    </main>
  );
}

export default function SearchPage() {
  return (
    <div className="min-h-screen page-transition">
      <Header />
      <Suspense fallback={
        <main className="pt-24 max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="h-8 skeleton rounded w-1/3 mb-8" />
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="space-y-4">
                <div className="aspect-video skeleton rounded-2xl" />
                <div className="h-4 skeleton rounded w-3/4" />
              </div>
            ))}
          </div>
        </main>
      }>
        <SearchContent />
      </Suspense>
    </div>
  );
}
