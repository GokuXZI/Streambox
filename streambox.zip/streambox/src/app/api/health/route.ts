import { isDatabaseOk } from "@/lib/database";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const ok = isDatabaseOk();
    return Response.json({ ok });
  } catch {
    return Response.json({ ok: false }, { status: 500 });
  }
}
