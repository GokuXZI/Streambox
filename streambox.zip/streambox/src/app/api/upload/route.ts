import { NextRequest } from "next/server";
import { v4 as uuidv4 } from "uuid";
import { insertVideo, updateVideoMetadata } from "@/lib/database";
import { sanitizeFilename, isValidVideoFile, DIRS } from "@/lib/storage";
import { probeVideo, generateThumbnail, isBrowserCompatible } from "@/lib/ffmpeg";
import { encryptFile } from "@/lib/encryption";
import fs from "fs";
import path from "path";

export const dynamic = "force-dynamic";

const MAX_SIZE = (parseInt(process.env.UPLOAD_MAX_SIZE_MB || "4096")) * 1024 * 1024;

function validateAdminTokenFromHeader(request: NextRequest): boolean {
  const token = process.env.ADMIN_TOKEN || "streambox-admin-2024";
  const auth = request.headers.get("authorization");
  if (auth) {
    const t = auth.replace("Bearer ", "").trim();
    if (t === token) return true;
  }
  const xToken = request.headers.get("x-admin-token");
  if (xToken === token) return true;
  return false;
}

export async function POST(request: NextRequest) {
  try {
    if (!validateAdminTokenFromHeader(request)) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const contentType = request.headers.get("content-type") || "";
    if (!contentType.includes("multipart/form-data")) {
      return Response.json({ error: "Must be multipart/form-data" }, { status: 400 });
    }

    const formData = await request.formData();
    const file = formData.get("video") as File | null;
    const title = (formData.get("title") as string) || "";
    const description = (formData.get("description") as string) || "";

    if (!file) {
      return Response.json({ error: "No video file provided" }, { status: 400 });
    }

    if (file.size > MAX_SIZE) {
      return Response.json({ error: `File too large. Maximum size is ${process.env.UPLOAD_MAX_SIZE_MB || 4096}MB` }, { status: 400 });
    }

    if (file.size === 0) {
      return Response.json({ error: "File is empty" }, { status: 400 });
    }

    const originalFilename = sanitizeFilename(file.name);
    if (!isValidVideoFile(originalFilename, file.type)) {
      return Response.json({ error: "Invalid video format. Supported: MP4, WebM, MKV, MOV, AVI" }, { status: 400 });
    }

    const id = uuidv4();
    const ext = path.extname(originalFilename);
    const storedFilename = `${id}${ext}`;
    const tempPath = path.join(DIRS.temp, storedFilename);
    const encryptedPath = path.join(DIRS.videos, `${id}.enc`);

    const videoTitle = title.trim() || path.basename(originalFilename, ext).replace(/[_-]/g, " ");

    // Create DB record in uploading state
    insertVideo({
      id,
      title: videoTitle.substring(0, 500),
      description: description.substring(0, 5000),
      original_filename: originalFilename,
      storage_path: encryptedPath, // Store encrypted path
      mime_type: file.type || "video/mp4",
      file_size: file.size,
      status: "uploading",
    });

    try {
      // Write file to temp
      const arrayBuffer = await file.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      fs.writeFileSync(tempPath, buffer);

      // Update status to processing
      updateVideoMetadata(id, { status: "processing" });

      // Probe metadata before encryption
      const metadata = await probeVideo(tempPath);
      updateVideoMetadata(id, {
        duration: metadata.duration,
        width: metadata.width,
        height: metadata.height,
        fps: metadata.fps,
        bitrate: metadata.bitrate,
        video_codec: metadata.video_codec,
        audio_codec: metadata.audio_codec,
        container_format: metadata.container_format,
      });

      // Generate thumbnail before encryption
      const thumbnailFilename = `${id}.jpg`;
      const thumbnailPath = path.join(DIRS.thumbnails, thumbnailFilename);

      let thumbTimestamp = "00:00:02";
      if (metadata.duration && metadata.duration > 10) {
        const seekTo = Math.min(Math.floor(metadata.duration * 0.1), 30);
        const m = Math.floor(seekTo / 60);
        const s = seekTo % 60;
        thumbTimestamp = `00:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
      }

      const thumbSuccess = await generateThumbnail(tempPath, thumbnailPath, thumbTimestamp);
      if (thumbSuccess) {
        updateVideoMetadata(id, { thumbnail_path: thumbnailPath });
      }

      // Encrypt the video file
      console.log(`Encrypting video ${id}...`);
      await encryptFile(tempPath, encryptedPath);
      console.log(`Video ${id} encrypted successfully`);

      // Delete temp file
      if (fs.existsSync(tempPath)) {
        fs.unlinkSync(tempPath);
      }

      // Check browser compatibility - log but still mark ready
      if (!isBrowserCompatible(metadata)) {
        console.log(`Video ${id} may not be directly browser-compatible (codec: ${metadata.video_codec}/${metadata.audio_codec}). Original preserved.`);
      }

      // Mark as ready
      updateVideoMetadata(id, { status: "ready", file_size: file.size });

      return Response.json({
        success: true,
        id,
        title: videoTitle,
        message: "Video uploaded and encrypted successfully",
      }, { status: 201 });

    } catch (processingError) {
      console.error("Processing error:", processingError);
      
      // Clean up temp file if it exists
      if (fs.existsSync(tempPath)) {
        try { fs.unlinkSync(tempPath); } catch { /* ignore */ }
      }

      // If encryption failed, clean up
      if (fs.existsSync(encryptedPath)) {
        try { fs.unlinkSync(encryptedPath); } catch { /* ignore */ }
      }

      updateVideoMetadata(id, {
        status: "error",
        processing_error: String(processingError),
      });
      return Response.json({ error: "Failed to process and encrypt video" }, { status: 500 });
    }
  } catch (error) {
    console.error("Upload error:", error);
    return Response.json({ error: "Upload failed" }, { status: 500 });
  }
}
