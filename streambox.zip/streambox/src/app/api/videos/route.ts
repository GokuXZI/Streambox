import { NextRequest } from "next/server";
import { getVideos } from "@/lib/database";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const page = Math.max(1, parseInt(url.searchParams.get("page") || "1"));
    const limit = Math.min(50, Math.max(1, parseInt(url.searchParams.get("limit") || "24")));
    const search = url.searchParams.get("search") || undefined;
    const offset = (page - 1) * limit;

    const { videos, total } = getVideos({ limit, offset, search, status: "ready" });

    return Response.json({
      videos,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("Error fetching videos:", error);
    return Response.json({ error: "Failed to fetch videos" }, { status: 500 });
  }
}
