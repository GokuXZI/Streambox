import { NextRequest } from "next/server";
import { getVideoById } from "@/lib/database";
import { getContentType } from "@/lib/storage";
import { validateStreamToken, decryptRange, createDecryptStream } from "@/lib/encryption";
import fs from "fs";
import path from "path";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(
  request: NextRequest,
  context: RouteContext
) {
  try {
    const { id } = await context.params;
    if (!id || typeof id !== "string" || id.length > 100) {
      return new Response("Invalid video ID", { status: 400 });
    }

    // Validate token
    const url = new URL(request.url);
    const token = url.searchParams.get("token");
    
    if (!token) {
      return new Response("Access token required", { status: 401 });
    }
    
    if (!validateStreamToken(token, id)) {
      return new Response("Invalid or expired token", { status: 403 });
    }

    // Check referer
    const referer = request.headers.get("referer") || "";
    const host = request.headers.get("host") || "";
    
    if (referer && !referer.includes(host) && !referer.includes("localhost")) {
      return new Response("Invalid request origin", { status: 403 });
    }

    const video = getVideoById(id);
    if (!video || video.status !== "ready") {
      return new Response("Video not found", { status: 404 });
    }

    const videoPath = path.resolve(video.storage_path);

    if (!fs.existsSync(videoPath)) {
      return new Response("Video file not found", { status: 404 });
    }

    // Get content type from original filename
    const contentType = video.mime_type || getContentType(video.original_filename);
    
    // Check if this is an encrypted file
    const isEncrypted = videoPath.endsWith(".enc");
    
    if (!isEncrypted) {
      // Legacy unencrypted file - stream directly
      return streamUnencryptedFile(request, videoPath, contentType);
    }

    // For encrypted files, we need to handle Range requests carefully
    const rangeHeader = request.headers.get("range");
    
    // Get approximate file size (original size stored in DB)
    const originalSize = video.file_size;

    if (rangeHeader) {
      const parts = rangeHeader.replace(/bytes=/, "").split("-");
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : originalSize - 1;

      if (isNaN(start) || start < 0 || start >= originalSize) {
        return new Response("Range Not Satisfiable", {
          status: 416,
          headers: {
            "Content-Range": `bytes */${originalSize}`,
          },
        });
      }

      const clampedEnd = Math.min(end, originalSize - 1);
      const chunkSize = clampedEnd - start + 1;

      try {
        // Decrypt the requested range
        const decryptedData = await decryptRange(videoPath, start, clampedEnd);

        return new Response(new Uint8Array(decryptedData), {
          status: 206,
          headers: {
            "Content-Range": `bytes ${start}-${start + decryptedData.length - 1}/${originalSize}`,
            "Accept-Ranges": "bytes",
            "Content-Length": String(decryptedData.length),
            "Content-Type": contentType,
            "Cache-Control": "no-store, no-cache, must-revalidate",
            "X-Content-Type-Options": "nosniff",
          },
        });
      } catch (decryptError) {
        console.error("Decryption error:", decryptError);
        return new Response("Decryption failed", { status: 500 });
      }
    }

    // No range header - stream entire decrypted file
    try {
      const { stream, decipher, totalSize } = createDecryptStream(videoPath);
      
      const webStream = new ReadableStream({
        start(controller) {
          stream.pipe(decipher);
          
          decipher.on("data", (chunk: Buffer) => {
            controller.enqueue(new Uint8Array(chunk));
          });
          
          decipher.on("end", () => {
            controller.close();
          });
          
          decipher.on("error", (err) => {
            console.error("Decipher error:", err);
            controller.error(err);
          });
          
          stream.on("error", (err) => {
            console.error("Stream error:", err);
            controller.error(err);
          });
        },
        cancel() {
          stream.destroy();
        },
      });

      return new Response(webStream, {
        status: 200,
        headers: {
          "Accept-Ranges": "bytes",
          "Content-Length": String(originalSize),
          "Content-Type": contentType,
          "Cache-Control": "no-store, no-cache, must-revalidate",
          "X-Content-Type-Options": "nosniff",
        },
      });
    } catch (streamError) {
      console.error("Streaming error:", streamError);
      return new Response("Streaming failed", { status: 500 });
    }
  } catch (error) {
    console.error("Streaming error:", error);
    return new Response("Internal Server Error", { status: 500 });
  }
}

// Helper for unencrypted files (legacy support)
function streamUnencryptedFile(request: NextRequest, filePath: string, contentType: string) {
  const stat = fs.statSync(filePath);
  const fileSize = stat.size;
  const rangeHeader = request.headers.get("range");

  if (rangeHeader) {
    const parts = rangeHeader.replace(/bytes=/, "").split("-");
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

    if (isNaN(start) || start < 0 || start >= fileSize) {
      return new Response("Range Not Satisfiable", {
        status: 416,
        headers: { "Content-Range": `bytes */${fileSize}` },
      });
    }

    const clampedEnd = Math.min(end, fileSize - 1);
    const chunkSize = clampedEnd - start + 1;

    const stream = fs.createReadStream(filePath, { start, end: clampedEnd });
    const webStream = nodeStreamToWeb(stream);

    return new Response(webStream, {
      status: 206,
      headers: {
        "Content-Range": `bytes ${start}-${clampedEnd}/${fileSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": String(chunkSize),
        "Content-Type": contentType,
        "Cache-Control": "no-store",
      },
    });
  }

  const stream = fs.createReadStream(filePath);
  const webStream = nodeStreamToWeb(stream);

  return new Response(webStream, {
    status: 200,
    headers: {
      "Accept-Ranges": "bytes",
      "Content-Length": String(fileSize),
      "Content-Type": contentType,
      "Cache-Control": "no-store",
    },
  });
}

function nodeStreamToWeb(nodeStream: fs.ReadStream): ReadableStream<Uint8Array> {
  return new ReadableStream({
    start(controller) {
      nodeStream.on("data", (chunk: string | Buffer) => {
        if (typeof chunk === "string") {
          controller.enqueue(new TextEncoder().encode(chunk));
        } else {
          controller.enqueue(new Uint8Array(chunk));
        }
      });
      nodeStream.on("end", () => controller.close());
      nodeStream.on("error", (err) => controller.error(err));
    },
    cancel() {
      nodeStream.destroy();
    },
  });
}
