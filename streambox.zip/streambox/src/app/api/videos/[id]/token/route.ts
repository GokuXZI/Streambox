import { NextRequest } from "next/server";
import { getVideoById } from "@/lib/database";
import { generateStreamToken } from "@/lib/encryption";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(
  request: NextRequest,
  context: RouteContext
) {
  try {
    const { id } = await context.params;
    
    if (!id || typeof id !== "string" || id.length > 100) {
      return Response.json({ error: "Invalid video ID" }, { status: 400 });
    }

    const video = getVideoById(id);
    if (!video || video.status !== "ready") {
      return Response.json({ error: "Video not found" }, { status: 404 });
    }

    // Check referer - must come from our site
    const referer = request.headers.get("referer") || "";
    const host = request.headers.get("host") || "";
    
    // Basic referer check (can be bypassed but adds a layer)
    if (referer && !referer.includes(host) && !referer.includes("localhost")) {
      return Response.json({ error: "Invalid request origin" }, { status: 403 });
    }

    // Generate token valid for 5 minutes
    const token = generateStreamToken(id, 300);
    
    return Response.json({ 
      token,
      expiresIn: 300,
    }, {
      headers: {
        "Cache-Control": "no-store, no-cache, must-revalidate",
        "Pragma": "no-cache",
      }
    });
  } catch (error) {
    console.error("Token generation error:", error);
    return Response.json({ error: "Failed to generate token" }, { status: 500 });
  }
}
