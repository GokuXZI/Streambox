import { NextRequest } from "next/server";
import { getVideoById, updateVideoMetadata, deleteVideo } from "@/lib/database";
import { isAdminRequest } from "@/lib/auth";
import { deleteFile, fileExists } from "@/lib/storage";
import { getResolutionLabel, formatDuration, formatFileSize } from "@/lib/ffmpeg";
import path from "path";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(
  _request: NextRequest,
  context: RouteContext
) {
  try {
    const { id } = await context.params;
    if (!id || typeof id !== "string" || id.length > 100) {
      return Response.json({ error: "Invalid video ID" }, { status: 400 });
    }

    const video = getVideoById(id);
    if (!video) {
      return Response.json({ error: "Video not found" }, { status: 404 });
    }

    return Response.json({
      ...video,
      resolution_label: getResolutionLabel(video.width, video.height),
      duration_formatted: formatDuration(video.duration),
      file_size_formatted: formatFileSize(video.file_size),
    });
  } catch (error) {
    console.error("Error fetching video:", error);
    return Response.json({ error: "Failed to fetch video" }, { status: 500 });
  }
}

export async function PATCH(
  request: NextRequest,
  context: RouteContext
) {
  try {
    const isAdmin = await isAdminRequest();
    if (!isAdmin) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await context.params;
    if (!id || typeof id !== "string") {
      return Response.json({ error: "Invalid video ID" }, { status: 400 });
    }

    const video = getVideoById(id);
    if (!video) {
      return Response.json({ error: "Video not found" }, { status: 404 });
    }

    const body = await request.json();
    const updates: Record<string, unknown> = {};

    if (body.title !== undefined) {
      const title = String(body.title).trim();
      if (title.length === 0 || title.length > 500) {
        return Response.json({ error: "Title must be 1-500 characters" }, { status: 400 });
      }
      updates.title = title;
    }
    if (body.description !== undefined) {
      updates.description = String(body.description).substring(0, 5000);
    }

    updateVideoMetadata(id, updates);
    const updated = getVideoById(id);
    return Response.json(updated);
  } catch (error) {
    console.error("Error updating video:", error);
    return Response.json({ error: "Failed to update video" }, { status: 500 });
  }
}

export async function DELETE(
  _request: NextRequest,
  context: RouteContext
) {
  try {
    const isAdmin = await isAdminRequest();
    if (!isAdmin) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await context.params;
    if (!id || typeof id !== "string") {
      return Response.json({ error: "Invalid video ID" }, { status: 400 });
    }

    const video = getVideoById(id);
    if (!video) {
      return Response.json({ error: "Video not found" }, { status: 404 });
    }

    // Delete files
    if (video.storage_path && fileExists(path.resolve(video.storage_path))) {
      deleteFile(path.resolve(video.storage_path));
    }
    if (video.processed_path && fileExists(path.resolve(video.processed_path))) {
      deleteFile(path.resolve(video.processed_path));
    }
    if (video.thumbnail_path && fileExists(path.resolve(video.thumbnail_path))) {
      deleteFile(path.resolve(video.thumbnail_path));
    }

    deleteVideo(id);
    return Response.json({ success: true });
  } catch (error) {
    console.error("Error deleting video:", error);
    return Response.json({ error: "Failed to delete video" }, { status: 500 });
  }
}
