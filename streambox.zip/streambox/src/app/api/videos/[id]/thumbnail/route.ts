import { NextRequest } from "next/server";
import { getVideoById } from "@/lib/database";
import fs from "fs";
import path from "path";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ id: string }> };

export async function GET(
  _request: NextRequest,
  context: RouteContext
) {
  try {
    const { id } = await context.params;
    if (!id || typeof id !== "string" || id.length > 100) {
      return new Response("Invalid video ID", { status: 400 });
    }

    const video = getVideoById(id);
    if (!video) {
      return new Response("Video not found", { status: 404 });
    }

    if (!video.thumbnail_path) {
      // Return a placeholder SVG
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360">
        <rect width="640" height="360" fill="#1e293b"/>
        <text x="320" y="180" text-anchor="middle" fill="#94a3b8" font-family="sans-serif" font-size="24">No Thumbnail</text>
        <polygon points="300,140 300,220 360,180" fill="#475569"/>
      </svg>`;
      return new Response(svg, {
        status: 200,
        headers: {
          "Content-Type": "image/svg+xml",
          "Cache-Control": "public, max-age=3600",
        },
      });
    }

    const thumbnailPath = path.resolve(video.thumbnail_path);
    if (!fs.existsSync(thumbnailPath)) {
      return new Response("Thumbnail not found", { status: 404 });
    }

    const data = fs.readFileSync(thumbnailPath);
    const ext = path.extname(thumbnailPath).toLowerCase();
    const contentType = ext === ".png" ? "image/png" : ext === ".webp" ? "image/webp" : "image/jpeg";

    return new Response(data, {
      status: 200,
      headers: {
        "Content-Type": contentType,
        "Content-Length": String(data.length),
        "Cache-Control": "public, max-age=86400",
      },
    });
  } catch (error) {
    console.error("Thumbnail error:", error);
    return new Response("Internal Server Error", { status: 500 });
  }
}
