import { NextRequest } from "next/server";
import { getAllVideosForAdmin } from "@/lib/database";
import { isAdminRequest } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  try {
    const isAdmin = await isAdminRequest();
    if (!isAdmin) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const url = new URL(request.url);
    const page = Math.max(1, parseInt(url.searchParams.get("page") || "1"));
    const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get("limit") || "50")));
    const offset = (page - 1) * limit;

    const { videos, total } = getAllVideosForAdmin({ limit, offset });

    return Response.json({
      videos,
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("Admin videos error:", error);
    return Response.json({ error: "Failed to fetch videos" }, { status: 500 });
  }
}
