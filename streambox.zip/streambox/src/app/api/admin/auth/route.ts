import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const token = body.token;
    const adminToken = process.env.ADMIN_TOKEN || "streambox-admin-2024";

    if (token === adminToken) {
      return Response.json({ success: true });
    }

    return Response.json({ error: "Invalid token" }, { status: 401 });
  } catch {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }
}
