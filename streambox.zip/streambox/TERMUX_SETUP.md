# StreamVault - Next-Gen Encrypted Video Streaming

A cutting-edge, secure video streaming platform with military-grade encryption designed for Android Termux.

## ✨ Features

### 🎨 Modern UI
- Glassmorphism design with neon glow effects
- Animated gradient backgrounds
- Smooth transitions and micro-interactions
- Fully responsive (mobile-first)
- Dark theme optimized for OLED

### 🎬 Advanced Video Player
- Custom controls with smooth animations
- Keyboard shortcuts (Space, F, M, J/L, etc.)
- Double-tap to seek (mobile)
- Theater mode
- Picture-in-Picture
- Playback speed (0.25x - 2x)
- Brightness control
- Buffer visualization
- Auto-hide controls
- Skip indicators

### 🔒 Security
- AES-256-CBC encryption
- Token-based streaming (5 min expiry)
- Auto token refresh
- Anti-download protection
- Right-click disabled
- Keyboard shortcuts blocked
- No caching

### ⚡ Performance
- Lazy loading with Intersection Observer
- Optimized streaming
- Efficient encryption/decryption
- No buffering issues

---

## 🚀 Quick Start (Termux)

### 1. Install Termux
Download from **F-Droid** (NOT Play Store)

### 2. Setup
```bash
pkg update && pkg upgrade -y
pkg install -y nodejs git ffmpeg python
termux-setup-storage
```

### 3. Clone & Install
```bash
git clone <your-repo-url> streamvault
cd streamvault
npm install
```

### 4. Configure
```bash
cat > .env << 'EOF'
ADMIN_TOKEN=YourSecretToken123!
UPLOAD_MAX_SIZE_MB=4096
STORAGE_PATH=storage
SQLITE_DB_PATH=data/streaming.db
EOF
```

### 5. Create Directories
```bash
mkdir -p storage/videos storage/thumbnails storage/processed storage/temp data
```

### 6. Build
```bash
npx next build --no-turbo
```

### 7. Start
```bash
npm start
```

### 8. Access
- Local: `http://localhost:3000`
- Network: `http://<your-ip>:3000`
- Admin: `http://localhost:3000/admin`

---

## 🎮 Keyboard Shortcuts

| Key | Action |
|-----|--------|
| Space / K | Play/Pause |
| F | Fullscreen |
| M | Mute |
| J / ← | Rewind 10s |
| L / → | Forward 10s |
| ↑ / ↓ | Volume |
| 0-9 | Seek % |
| T | Theater mode |
| ? | Show shortcuts |

---

## 📱 Mobile Gestures

- **Double-tap left**: Rewind 10s
- **Double-tap right**: Forward 10s
- **Single tap**: Play/Pause
- **Swipe on progress**: Seek

---

## 🔐 Security Architecture

### Encryption
- Algorithm: AES-256-CBC
- Key: Auto-generated 256-bit
- IV: 16-byte random per file
- Storage: `data/.encryption_key`

### Token System
- Format: Encrypted JSON
- Expiry: 5 minutes
- Auto-refresh: 4 minutes
- Contains: videoId, timestamp, nonce

### Protection Layers
1. Encrypted video files (.enc)
2. Token-based access
3. Referer validation
4. No-cache headers
5. Context menu blocked
6. Dev tools shortcuts blocked

---

## 📁 File Structure

```
streamvault/
├── data/
│   ├── .encryption_key     # ⚠️ BACKUP THIS!
│   └── streaming.db
├── storage/
│   ├── videos/*.enc       # Encrypted videos
│   ├── thumbnails/        # Generated thumbnails
│   └── temp/              # Upload temp
├── src/
│   ├── app/               # Pages & API
│   ├── components/        # UI components
│   └── lib/               # Core utilities
└── .env                   # Configuration
```

---

## 🌐 VPS Deployment

### Requirements
- Node.js 18+
- 1GB RAM minimum
- FFmpeg (optional)

### Setup
```bash
git clone <repo> /var/www/streamvault
cd /var/www/streamvault
npm install
npm run build
```

### PM2 (Recommended)
```bash
npm install -g pm2
pm2 start npm --name "streamvault" -- start
pm2 save
pm2 startup
```

### Nginx Reverse Proxy
```nginx
server {
    listen 80;
    server_name your-domain.com;

    client_max_body_size 4G;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### SSL (Let's Encrypt)
```bash
apt install certbot python3-certbot-nginx
certbot --nginx -d your-domain.com
```

---

## ⚠️ Important

### Backup These Files!
- `data/.encryption_key` - Without this, encrypted videos are LOST
- `data/streaming.db` - Video metadata
- `storage/videos/` - Encrypted videos

### Performance Tips
- Use SSD storage
- Allocate enough RAM
- Use PM2 cluster mode for multi-core

---

## 🔧 Troubleshooting

### Turbopack Error
```bash
npx next build --no-turbo
```

### Memory Issues
```bash
export NODE_OPTIONS="--max-old-space-size=512"
npx next build --no-turbo
```

### Permission Denied
```bash
termux-setup-storage
```

### Port in Use
```bash
PORT=8080 npm start
```

---

## 📊 API Reference

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | /api/videos | - | List videos |
| GET | /api/videos/:id | - | Video details |
| GET | /api/videos/:id/token | - | Get stream token |
| GET | /api/videos/:id/stream?token=X | Token | Stream video |
| GET | /api/videos/:id/thumbnail | - | Thumbnail |
| POST | /api/upload | Admin | Upload video |
| PATCH | /api/videos/:id | Admin | Update |
| DELETE | /api/videos/:id | Admin | Delete |

---

## 📜 License

MIT - For personal/private use.

---

Built with ❤️ for privacy-conscious users.
